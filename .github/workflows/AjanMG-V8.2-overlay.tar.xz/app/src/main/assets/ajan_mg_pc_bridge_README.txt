Ajan M&G PC Bridge

1) Install Python 3 on your computer.
2) Put ajan_mg_pc_bridge.py in a folder.
3) Choose a long private token.
4) Windows PowerShell:
   $env:AJAN_TOKEN="YOUR_LONG_TOKEN"; python ajan_mg_pc_bridge.py
   macOS/Linux:
   AJAN_TOKEN="YOUR_LONG_TOKEN" python3 ajan_mg_pc_bridge.py
5) On the phone, open Ajan M&G > Settings.
   PC Bridge URL: http://COMPUTER_LOCAL_IP:8765
   PC Bridge token: the same token.
6) Keep the terminal open. For safer file access, set AJAN_ROOT to a dedicated work folder.

The bridge never bypasses OS permissions. Do not expose port 8765 directly to the public internet.
