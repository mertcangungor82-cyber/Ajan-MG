#!/usr/bin/env python3
"""Ajan M&G Desktop Bridge - personal use.
Windows PowerShell example:
  $env:AJAN_TOKEN="CHANGE_ME_LONG_RANDOM_TOKEN"; python ajan_mg_pc_bridge.py
macOS/Linux:
  AJAN_TOKEN="CHANGE_ME_LONG_RANDOM_TOKEN" python3 ajan_mg_pc_bridge.py
Optional: AJAN_ROOT limits accessible files. Default is the user's home folder.
"""
import json, os, subprocess, platform, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
TOKEN=os.environ.get("AJAN_TOKEN","").strip()
ROOT=Path(os.environ.get("AJAN_ROOT",str(Path.home()))).resolve()
ALLOWED={"list_files","read_file","write_file","open_app","open_url","run_command"}

if not TOKEN:
    print("ERROR: AJAN_TOKEN is required. Set a long private token before starting the bridge.")
    sys.exit(2)

def safe_path(p):
    q=(ROOT/p).resolve() if not Path(p).is_absolute() else Path(p).resolve()
    if ROOT not in q.parents and q!=ROOT: raise ValueError("Path outside AJAN_ROOT")
    return q

def run(cmd,p):
    if cmd=="list_files": return [x.name for x in safe_path(p.get("path",".")).iterdir()][:500]
    if cmd=="read_file": return safe_path(p["path"]).read_text(errors="replace")[:200000]
    if cmd=="write_file":
        q=safe_path(p["path"]); q.parent.mkdir(parents=True,exist_ok=True); q.write_text(p.get("content","")); return str(q)
    if cmd=="open_url":
        import webbrowser; webbrowser.open(p["url"]); return "opened"
    if cmd=="open_app":
        name=p["name"]
        if platform.system()=="Windows": subprocess.Popen(["cmd","/c","start","",name],shell=False)
        elif platform.system()=="Darwin": subprocess.Popen(["open","-a",name])
        else: subprocess.Popen([name])
        return "opened"
    if cmd=="run_command":
        cp=subprocess.run(p["command"],shell=True,cwd=str(ROOT),capture_output=True,text=True,timeout=120)
        return {"code":cp.returncode,"stdout":cp.stdout[-12000:],"stderr":cp.stderr[-12000:]}
    raise ValueError("unsupported")

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_POST(self):
        if self.path!="/v1/command": self.send_error(404); return
        if self.headers.get("X-Ajan-Token","")!=TOKEN: self.send_error(401); return
        try:
            n=min(int(self.headers.get("Content-Length","0")),2_000_000)
            req=json.loads(self.rfile.read(n) or b"{}")
            cmd=req.get("command",""); payload=req.get("payload",{})
            if cmd not in ALLOWED: raise ValueError("unsupported command")
            result=run(cmd,payload); raw=json.dumps({"ok":True,"result":result},ensure_ascii=False).encode()
            self.send_response(200); self.send_header("Content-Type","application/json; charset=utf-8"); self.end_headers(); self.wfile.write(raw)
        except Exception as e:
            raw=json.dumps({"ok":False,"error":str(e)},ensure_ascii=False).encode()
            self.send_response(400); self.send_header("Content-Type","application/json; charset=utf-8"); self.end_headers(); self.wfile.write(raw)

if __name__=="__main__":
    print(f"Ajan M&G PC Bridge: http://0.0.0.0:8765  root={ROOT}")
    print("Keep this terminal open while Ajan M&G is controlling the PC.")
    ThreadingHTTPServer(("0.0.0.0",8765),H).serve_forever()
