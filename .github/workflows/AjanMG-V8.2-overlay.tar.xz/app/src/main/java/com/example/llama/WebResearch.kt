package com.example.llama

import android.text.Html
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object WebResearch {
    private val cities = listOf(
        "Adana","Adıyaman","Afyonkarahisar","Ağrı","Amasya","Ankara","Antalya","Artvin","Aydın","Balıkesir","Bilecik","Bingöl","Bitlis","Bolu","Burdur","Bursa","Çanakkale","Çankırı","Çorum","Denizli","Diyarbakır","Edirne","Elazığ","Erzincan","Erzurum","Eskişehir","Gaziantep","Giresun","Gümüşhane","Hakkari","Hatay","Isparta","Mersin","İstanbul","İzmir","Kars","Kastamonu","Kayseri","Kırklareli","Kırşehir","Kocaeli","Konya","Kütahya","Malatya","Manisa","Kahramanmaraş","Mardin","Muğla","Muş","Nevşehir","Niğde","Ordu","Rize","Sakarya","Samsun","Siirt","Sinop","Sivas","Tekirdağ","Tokat","Trabzon","Tunceli","Şanlıurfa","Uşak","Van","Yozgat","Zonguldak","Aksaray","Bayburt","Karaman","Kırıkkale","Batman","Şırnak","Bartın","Ardahan","Iğdır","Yalova","Karabük","Kilis","Osmaniye","Düzce"
    )

    data class Source(val title: String, val url: String, val snippet: String)

    data class Report(
        val query: String,
        val sources: List<Source>,
        val directAnswer: String? = null
    ) {
        fun promptText(): String = buildString {
            sources.take(6).forEachIndexed { i, s ->
                append("KAYNAK ${i + 1}\n")
                append("Başlık: ${s.title}\n")
                append("URL: ${s.url}\n")
                append("İçerik: ${s.snippet.take(1800)}\n\n")
            }
        }

        fun fallbackAnswer(): String {
            if (!directAnswer.isNullOrBlank()) return directAnswer
            if (sources.isEmpty()) return "Şu anda web'den güvenilir bir sonuç alamadım. Bağlantıyı kontrol edip tekrar deneyebilirsin."
            return buildString {
                append("Web'de bulabildiğim en ilgili güncel sonuçlar:\n")
                sources.take(3).forEachIndexed { i, s ->
                    append("${i + 1}) ${s.title}")
                    if (s.snippet.isNotBlank()) append(" — ${s.snippet.take(260)}")
                    append("\n${s.url}\n")
                }
            }.trim()
        }
    }

    suspend fun research(
        query: String,
        progress: (String) -> Unit = {}
    ): Report = withContext(Dispatchers.IO) {
        weatherAnswer(query)?.let { return@withContext Report(query, emptyList(), it) }
        footballAnswer(query)?.let { return@withContext Report(query, emptyList(), it) }
        populationAnswer(query)?.let { return@withContext Report(query, emptyList(), it) }
        wikiDirectAnswer(query)?.let { return@withContext Report(query, emptyList(), it) }

        progress("Güncel kaynaklar aranıyor…")
        val gathered = coroutineScope {
            listOf(
                async { runCatching { bingWeb(query) }.getOrDefault(emptyList()) },
                async { runCatching { googleNews(query) }.getOrDefault(emptyList()) },
                async { runCatching { wikipedia(query) }.getOrDefault(emptyList()) }
            ).awaitAll().flatten()
        }

        val unique = gathered
            .filter { it.url.startsWith("http") && it.title.isNotBlank() }
            .distinctBy { (it.title + "|" + it.url.substringBefore("#")).lowercase() }
            .take(7)

        if (unique.isEmpty()) return@withContext Report(query, emptyList())

        progress("Kaynaklar karşılaştırılıyor…")
        Report(query, unique, genericAnswer(unique))
    }

    private fun bingWeb(query: String): List<Source> {
        val q = URLEncoder.encode(query, "UTF-8")
        return readRss("https://www.bing.com/search?format=rss&setlang=tr-TR&cc=tr&q=$q", "")
    }

    private fun googleNews(query: String): List<Source> {
        val q = URLEncoder.encode(query, "UTF-8")
        return readRss("https://news.google.com/rss/search?q=$q&hl=tr&gl=TR&ceid=TR:tr", "Haber: ")
    }

    private fun readRss(url: String, titlePrefix: String): List<Source> {
        val c = connection(url)
        val p = Xml.newPullParser()
        val out = mutableListOf<Source>()
        c.inputStream.use { input ->
            p.setInput(input, "UTF-8")
            var event = p.eventType
            var inside = false
            var title = ""
            var link = ""
            var desc = ""
            while (event != XmlPullParser.END_DOCUMENT && out.size < 6) {
                when (event) {
                    XmlPullParser.START_TAG -> when (p.name.lowercase()) {
                        "item" -> { inside = true; title = ""; link = ""; desc = "" }
                        "title" -> if (inside) title = p.nextText()
                        "link" -> if (inside) link = p.nextText()
                        "description" -> if (inside) desc = p.nextText()
                    }
                    XmlPullParser.END_TAG -> if (inside && p.name.equals("item", true)) {
                        if (link.startsWith("http")) out += Source(titlePrefix + clean(title), link, clean(desc))
                        inside = false
                    }
                }
                event = p.next()
            }
        }
        c.disconnect()
        return out
    }

    private fun wikipedia(query: String): List<Source> {
        val q = URLEncoder.encode(query, "UTF-8")
        val raw = getText("https://tr.wikipedia.org/w/api.php?action=opensearch&search=$q&limit=3&namespace=0&format=json")
        val arr = JSONArray(raw)
        if (arr.length() < 4) return emptyList()
        val titles = arr.getJSONArray(1)
        val descriptions = arr.getJSONArray(2)
        val urls = arr.getJSONArray(3)
        val out = mutableListOf<Source>()
        for (i in 0 until titles.length()) {
            val u = urls.optString(i)
            if (u.startsWith("http")) out += Source("Wikipedia: ${titles.optString(i)}", u, descriptions.optString(i))
        }
        return out
    }

    private fun wikiDirectAnswer(query: String): String? {
        val q = fold(query)
        if (listOf("kimdir", "nedir", "nerede", "hakkında", "hakkinda").none { q.contains(it) }) return null
        return runCatching {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val root = JSONObject(getText("https://tr.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$encoded&gsrlimit=1&prop=extracts|info&exintro=1&explaintext=1&inprop=url&format=json"))
            val pages = root.optJSONObject("query")?.optJSONObject("pages") ?: return@runCatching null
            val keys = pages.keys(); if (!keys.hasNext()) return@runCatching null
            val page = pages.optJSONObject(keys.next()) ?: return@runCatching null
            val extract = clean(page.optString("extract")); if (extract.length < 50) return@runCatching null
            val answer = extract.split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" ").take(800)
            val url = page.optString("fullurl")
            answer + if (url.isNotBlank()) " Kaynak: $url" else " Kaynak: Türkçe Vikipedi."
        }.getOrNull()
    }

    private fun genericAnswer(sources: List<Source>): String = buildString {
        append("Web'de bulduğum en ilgili bilgiler:\n")
        sources.take(3).forEachIndexed { i, src ->
            append("${i + 1}. ${clean(src.title).take(220)}")
            val snip = clean(src.snippet).take(320)
            if (snip.isNotBlank()) append(" — $snip")
            append("\nKaynak: ${src.url}\n")
        }
    }.trim()

    private suspend fun footballAnswer(query: String): String? {
        val q = fold(query)
        val team = when {
            q.contains("galatasaray") || Regex("(^|\\s)gs(\\s|$)").containsMatchIn(q) -> "Galatasaray"
            q.contains("fenerbahce") || Regex("(^|\\s)fb(\\s|$)").containsMatchIn(q) -> "Fenerbahçe"
            q.contains("besiktas") || Regex("(^|\\s)bjk(\\s|$)").containsMatchIn(q) -> "Beşiktaş"
            q.contains("trabzonspor") || Regex("(^|\\s)ts(\\s|$)").containsMatchIn(q) -> "Trabzonspor"
            else -> return null
        }
        if (listOf("kacinci", "sirada", "sira", "puan durumu", "ligde").any { q.contains(it) }) {
            return runCatching { standingAnswer(team) }.getOrNull()
        }
        if (listOf("mac", "skor", "sonuc", "kazandi").any { q.contains(it) }) {
            return runCatching { lastMatchAnswer(team) }.getOrNull()
        }
        return null
    }

    private fun standingAnswer(team: String): String {
        val root = JSONObject(getText("https://site.api.espn.com/apis/v2/sports/soccer/tur.1/standings"))
        val entries = root.optJSONArray("children")?.optJSONObject(0)?.optJSONObject("standings")?.optJSONArray("entries") ?: error("Puan durumu alınamadı")
        for (i in 0 until entries.length()) {
            val e = entries.optJSONObject(i) ?: continue
            val name = e.optJSONObject("team")?.optString("displayName").orEmpty()
            if (!fold(name).contains(fold(team))) continue
            var points = ""; var played = ""; val stats = e.optJSONArray("stats") ?: JSONArray()
            for (j in 0 until stats.length()) {
                val st = stats.optJSONObject(j) ?: continue
                val v = st.optString("displayValue").ifBlank { st.optDouble("value", Double.NaN).let { if (it.isNaN()) "" else it.toInt().toString() } }
                when (st.optString("name")) { "points" -> points = v; "gamesPlayed" -> played = v }
            }
            return "$team Süper Lig'de ${i + 1}. sırada${if(points.isNotBlank()) "; $points puanı var" else ""}${if(played.isNotBlank()) " ($played maç)" else ""}. Kaynak: ESPN."
        }
        error("Takım bulunamadı")
    }

    private data class Match(val date: String, val league: String, val home: String, val away: String, val hs: String, val ascore: String)

    private suspend fun lastMatchAnswer(team: String): String = coroutineScope {
        val fmt = SimpleDateFormat("yyyyMMdd", Locale.US)
        val end = Calendar.getInstance(); val start = end.clone() as Calendar; start.add(Calendar.DAY_OF_YEAR, -45)
        val range = "${fmt.format(start.time)}-${fmt.format(end.time)}"
        val leagues = listOf("tur.1" to "Süper Lig", "uefa.champions" to "Şampiyonlar Ligi", "uefa.europa" to "Avrupa Ligi", "uefa.europa.conf" to "Konferans Ligi")
        val all = leagues.map { (slug,label) -> async { runCatching { matches(slug,label,range,team) }.getOrDefault(emptyList()) } }.awaitAll().flatten()
        val m = all.maxByOrNull { it.date } ?: error("Son maç bulunamadı")
        "$team son maçında ${m.home} ${m.hs}-${m.ascore} ${m.away} (${displayDate(m.date)}, ${m.league}). Kaynak: ESPN."
    }

    private fun matches(slug: String, label: String, range: String, team: String): List<Match> {
        val root = JSONObject(getText("https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard?dates=$range&limit=200"))
        val events = root.optJSONArray("events") ?: return emptyList(); val out = mutableListOf<Match>()
        for (i in 0 until events.length()) {
            val ev = events.optJSONObject(i) ?: continue
            if (ev.optJSONObject("status")?.optJSONObject("type")?.optBoolean("completed", false) != true) continue
            val cs = ev.optJSONArray("competitions")?.optJSONObject(0)?.optJSONArray("competitors") ?: continue
            var home: JSONObject? = null; var away: JSONObject? = null
            for (j in 0 until cs.length()) { val c=cs.optJSONObject(j)?:continue; if(c.optString("homeAway")=="home")home=c else if(c.optString("homeAway")=="away")away=c }
            val h=home?:continue; val a=away?:continue; val hn=h.optJSONObject("team")?.optString("displayName").orEmpty(); val an=a.optJSONObject("team")?.optString("displayName").orEmpty()
            if (!fold(hn).contains(fold(team)) && !fold(an).contains(fold(team))) continue
            out += Match(ev.optString("date"), label, hn, an, h.optString("score"), a.optString("score"))
        }
        return out
    }

    private fun displayDate(iso: String): String = runCatching {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(iso.take(10)) ?: Date()
        SimpleDateFormat("d MMMM yyyy", Locale("tr","TR")).format(d)
    }.getOrDefault(iso.take(10))

    private fun populationAnswer(query: String): String? {
        if (!fold(query).contains("nufus")) return null
        val city = cityFromQuery(query) ?: return null
        return runCatching {
            val q = URLEncoder.encode(city, "UTF-8")
            val pages = JSONObject(getText("https://tr.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$q&gsrlimit=2&prop=extracts|info&exintro=1&explaintext=1&inprop=url&format=json")).optJSONObject("query")?.optJSONObject("pages") ?: error("Sonuç yok")
            val keys=pages.keys(); var extract=""; var url=""
            while(keys.hasNext()) { val p=pages.optJSONObject(keys.next())?:continue; if(fold(p.optString("title")).contains(fold(city))){extract=p.optString("extract");url=p.optString("fullurl");break} }
            val sentence = extract.split(Regex("(?<=[.!?])\\s+")).firstOrNull { fold(it).contains("nufus") && Regex("\\d").containsMatchIn(it) } ?: extract.take(420)
            clean(sentence).take(500) + if(url.isNotBlank()) " Kaynak: $url" else " Kaynak: Türkçe Vikipedi."
        }.getOrNull()
    }

    private fun weatherAnswer(query: String): String? {
        val lower = fold(query)
        if (listOf("hava", "derece", "sicaklik", "yagmur").none { lower.contains(it) }) return null
        val city = cityFromQuery(query) ?: return null
        return runCatching { fetchWeather(city, lower.contains("yarin")) }.getOrNull()
    }

    private fun fetchWeather(city: String, tomorrow: Boolean): String {
        val q = URLEncoder.encode(city, "UTF-8")
        val geo = JSONObject(getText("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=tr&format=json"))
            .optJSONArray("results")?.optJSONObject(0) ?: error("Konum bulunamadı")
        val lat = geo.getDouble("latitude")
        val lon = geo.getDouble("longitude")
        val resolved = geo.optString("name", city)
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=3"
        val daily = JSONObject(getText(url)).getJSONObject("daily")
        val index = if (tomorrow) 1 else 0
        val max = daily.getJSONArray("temperature_2m_max").optDouble(index)
        val min = daily.getJSONArray("temperature_2m_min").optDouble(index)
        val rain = daily.getJSONArray("precipitation_probability_max").optInt(index)
        val code = daily.getJSONArray("weather_code").optInt(index)
        val day = if (tomorrow) "Yarın" else "Bugün"
        return "$day $resolved için hava ${weatherText(code)}. En yüksek ${formatTemp(max)}°C, en düşük ${formatTemp(min)}°C; yağış olasılığı %$rain. Kaynak: Open-Meteo."
    }

    private fun weatherText(code: Int) = when (code) {
        0 -> "açık"
        1, 2 -> "az bulutlu"
        3 -> "kapalı"
        45, 48 -> "sisli"
        51, 53, 55, 56, 57 -> "çiseli"
        61, 63, 65, 66, 67, 80, 81, 82 -> "yağmurlu"
        71, 73, 75, 77, 85, 86 -> "karlı"
        95, 96, 99 -> "gök gürültülü"
        else -> "değişken"
    }

    private fun formatTemp(value: Double): String = if (value.isNaN()) "?" else String.format(java.util.Locale.US, "%.0f", value)


    private fun getText(url: String): String {
        val c = connection(url)
        val text = c.inputStream.bufferedReader().use { it.readText().take(250000) }
        c.disconnect()
        return text
    }

    private fun connection(url: String) = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 4500
        readTimeout = 5500
        instanceFollowRedirects = true
        requestMethod = "GET"
        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AjanMG/2.0")
        setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.6")
        setRequestProperty("Accept-Encoding", "identity")
    }

    private fun cityFromQuery(query: String): String? {
        val q = fold(query)
        return cities.firstOrNull { q.contains(fold(it)) }
    }

    private fun fold(s: String): String {
        val x = s.lowercase(Locale("tr","TR")).replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c')
        return Normalizer.normalize(x, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    }

    private fun clean(s: String): String = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString()
        .replace(Regex("(?iu)\\bDEVAMI(?:\\.{2,})?\\b"), " ")
        .replace(Regex("(?iu)Facebook\\s+Twitter\\s+Instagram.*"), " ")
        .replace(Regex("\\s+"), " ").trim()
}
