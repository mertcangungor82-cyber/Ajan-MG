package com.example.llama

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.gguf.GgufMetadata
import com.arm.aichat.gguf.GgufMetadataReader
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private data class Brain(val type: String, val label: String, val config: OpenAiProviderConfig? = null)

    private lateinit var modelTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var messagesRv: RecyclerView
    private lateinit var userInputEt: EditText
    private lateinit var sendFab: FloatingActionButton
    private lateinit var progress: ProgressBar
    private lateinit var liveButton: Button
    private lateinit var attachButton: Button
    private lateinit var cameraButton: Button
    private lateinit var settingsButton: ImageButton

    private val messages = mutableListOf<Message>()
    private val adapter = MessageAdapter(messages)
    private lateinit var store: AgentStore
    private lateinit var router: AgentRouter
    private lateinit var secrets: SecureSecrets
    private var pendingAttachment: GeminiAgent.Attachment? = null
    private var job: Job? = null

    private lateinit var engine: InferenceEngine
    private var engineReady = false
    private var modelReady = false
    private val localBuf = StringBuilder()
    private val prefs by lazy { getSharedPreferences("ajan_mg_v8", MODE_PRIVATE) }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var liveMode = false
    private var listening = false

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) startListening() else toast("Mikrofon izni gerekli.") }
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) launchCamera() else toast("Kamera izni gerekli.") }
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        if (result.resultCode == RESULT_OK && uri != null) onPhotoCaptured(uri) else if (result.resultCode != RESULT_CANCELED) toast("Fotoğraf çekimi tamamlanamadı.")
    }
    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(::loadSelectedModel) }
    private val attachmentPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(::attachFile) }
    private val backupWriter = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { it?.let(::writeBackup) }
    private val restorePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(::restoreBackup) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(); setContentView(R.layout.activity_main)
        onBackPressedDispatcher.addCallback { if (liveMode) stopLive() else finish() }
        store = AgentStore(this); router = AgentRouter(store); secrets = SecureSecrets(this)
        bind(); restoreMessages(); setupButtons(); setupTts(); refreshHeader()
        LanguageLearner.bootstrap(store)
        lifecycleScope.launch(Dispatchers.Default) {
            runCatching { engine = AiChat.getInferenceEngine(applicationContext); engineReady = true }
            withContext(Dispatchers.Main) { autoLoadModel(); refreshHeader() }
        }
    }

    private fun bind() {
        modelTv = findViewById(R.id.model_info); statusTv = findViewById(R.id.status); messagesRv = findViewById(R.id.messages)
        userInputEt = findViewById(R.id.user_input); sendFab = findViewById(R.id.fab); progress = findViewById(R.id.progress)
        liveButton = findViewById(R.id.live_button); attachButton = findViewById(R.id.attach_button); cameraButton = findViewById(R.id.camera_button)
        settingsButton = findViewById(R.id.settings_button)
        messagesRv.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }; messagesRv.adapter = adapter
    }

    private fun setupButtons() {
        sendFab.setOnClickListener { submit() }
        userInputEt.setOnEditorActionListener { _, actionId, _ -> if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) { submit(); true } else false }
        settingsButton.setOnClickListener { showSettings() }
        cameraButton.setOnClickListener { ensureCamera() }
        attachButton.setOnClickListener { attachmentPicker.launch(arrayOf("image/*","application/pdf","text/*","application/json","text/csv","*/*")) }
        findViewById<Button>(R.id.image_button).setOnClickListener { prefill("4K görsel oluştur: ") }
        findViewById<Button>(R.id.video_button).setOnClickListener { prefill("9:16 profesyonel video oluştur: ") }
        findViewById<Button>(R.id.music_button).setOnClickListener { prefill("Tam uzunlukta müzik oluştur: ") }
        findViewById<Button>(R.id.excel_button).setOnClickListener { prefill("Excel oluştur. Veriler: ") }
        findViewById<Button>(R.id.web_button).setOnClickListener { prefill("İnternetten araştır ve doğrula: ") }
        findViewById<Button>(R.id.model_button).setOnClickListener { modelPicker.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.backup_button).setOnClickListener { backupWriter.launch("AjanMG-Yedek-${stamp()}.json") }
        findViewById<Button>(R.id.mic_button).setOnClickListener { liveMode = false; ensureMic() }
        liveButton.setOnClickListener { if (liveMode) stopLive() else { liveMode = true; liveButton.text = "Canlı • Açık"; speak("Canlı mod açık. Seni dinliyorum.") } }
    }

    private fun prefill(prefix: String) { userInputEt.setText(prefix); userInputEt.setSelection(userInputEt.text.length); userInputEt.requestFocus() }

    private fun submit() {
        val text = userInputEt.text.toString().trim(); if (text.isBlank()) return toast("Mesaj boş.")
        userInputEt.text = null; val att = pendingAttachment; pendingAttachment = null; attachButton.text = "Dosya"
        addUser(text + if (att != null) "  •  ${att.name}" else "")
        LanguageLearner.observeUser(store, text)
        if (text.startsWith("/")) { handleLegacy(router.route(text), att); return }
        if (providerMode() == "local") handleLegacy(router.route(text), att)
        else if (cloudPlan(att).isNotEmpty()) runCloud(text, att)
        else handleLegacy(router.route(text), att)
    }

    private fun handleLegacy(action: AgentAction, att: GeminiAgent.Attachment?) {
        when (action) {
            is AgentAction.Immediate -> finishAnswer(addAssistant(""), action.text)
            is AgentAction.Web -> runWeb(action.query)
            is AgentAction.Chat -> runLocal(router.promptForChat(action.text, att?.name, att?.let { if (it.mime.startsWith("text/")) String(it.bytes, Charsets.UTF_8) else null }))
            AgentAction.Backup -> backupWriter.launch("AjanMG-Yedek.json")
            AgentAction.Restore -> restorePicker.launch(arrayOf("application/json","*/*"))
            AgentAction.ImportFile -> attachmentPicker.launch(arrayOf("text/*","application/json","*/*"))
            AgentAction.LearnTurkish -> { val n = LanguageLearner.daily(store, true); finishAnswer(addAssistant(""), "Gelişim belleği güncellendi: $n yeni kural.") }
            is AgentAction.Project -> finishAnswer(addAssistant(""), "Bulut ajanı bağlıyken proje ve APK işlerini GitHub araçlarıyla yapabilirim. Ayarlardan GitHub token ekle.")
        }
    }

    private fun providerMode(): String = prefs.getString("ai_provider", "auto") ?: "auto"

    private fun groqConfig(): OpenAiProviderConfig = OpenAiProviderConfig(
        "groq", "Groq",
        secrets.get("groq_base_url").ifBlank { "https://api.groq.com/openai/v1" },
        secrets.get("groq_model").ifBlank { "openai/gpt-oss-120b" },
        secrets.get("groq_api_key")
    )

    private fun nvidiaConfig(): OpenAiProviderConfig = OpenAiProviderConfig(
        "nvidia", "NVIDIA NIM",
        secrets.get("nvidia_base_url").ifBlank { "https://integrate.api.nvidia.com/v1" },
        secrets.get("nvidia_model").ifBlank { "nvidia/nemotron-3-ultra-550b-a55b" },
        secrets.get("nvidia_api_key")
    )

    private fun customConfig(): OpenAiProviderConfig = OpenAiProviderConfig(
        "custom", "Özel API",
        secrets.get("custom_base_url"),
        secrets.get("custom_model"),
        secrets.get("custom_api_key")
    )

    private fun cloudPlan(att: GeminiAgent.Attachment?): List<Brain> {
        val mode = providerMode()
        val out = mutableListOf<Brain>()
        fun addGemini() { if (secrets.has("gemini_api_key") && out.none { it.type == "gemini" }) out += Brain("gemini", "Gemini") }
        fun addGroq() { val c=groqConfig(); if (c.apiKey.isNotBlank()) out += Brain("openai", "Groq", c) }
        fun addNvidia() { val c=nvidiaConfig(); if (c.apiKey.isNotBlank()) out += Brain("openai", "NVIDIA NIM", c) }
        fun addCustom() { val c=customConfig(); if (c.apiKey.isNotBlank() && c.baseUrl.isNotBlank() && c.model.isNotBlank()) out += Brain("openai", "Özel API", c) }
        when (mode) {
            "groq" -> addGroq()
            "nvidia" -> addNvidia()
            "custom" -> addCustom()
            "gemini" -> addGemini()
            "local" -> Unit
            else -> {
                val binary = att != null && !(att.mime.startsWith("text/") || att.mime.contains("json") || att.mime.contains("csv") || att.mime.contains("xml"))
                if (binary) addGemini()
                addGroq(); addNvidia(); addCustom(); addGemini()
            }
        }
        return out
    }

    private fun runCloud(text: String, att: GeminiAgent.Attachment?) {
        job?.cancel(); setBusy(true); val id = addAssistant("Ajan hazırlanıyor…")
        job = lifecycleScope.launch {
            var lastError = "Bulut sağlayıcısı yanıt vermedi."
            val plan = cloudPlan(att)
            for (brain in plan) {
                try {
                    val answer = withTimeoutOrNull(12 * 60 * 1000L) {
                        when (brain.type) {
                            "gemini" -> GeminiAgent(this@MainActivity, store, secrets) { msg -> runOnUiThread { status(msg); updateAssistant(id, msg) } }.respond(text, att)
                            else -> OpenAiAgent(this@MainActivity, store, secrets, brain.config!!){ msg -> runOnUiThread { status(msg); updateAssistant(id, msg) } }.respond(text, att)
                        }
                    } ?: error("İşlem zaman aşımına uğradı.")
                    store.increment("metric_${brain.label.lowercase(Locale.US).replace(" ", "_")}_success")
                    finishAnswer(id, answer)
                    return@launch
                } catch (e: Exception) {
                    lastError = "${brain.label}: ${e.message}"
                    store.increment("metric_cloud_error")
                    if (providerMode() != "auto") break
                    updateAssistant(id, "$lastError\nYedek sağlayıcı deneniyor…")
                }
            }
            if (modelReady) {
                updateAssistant(id, "$lastError\nYerel yedek devreye giriyor…")
                runLocal(router.promptForChat(text, att?.name, att?.let { if (it.mime.startsWith("text/")) String(it.bytes, Charsets.UTF_8) else null }), id)
            } else finishAnswer(id, "Bulut AI hatası: $lastError\nAyarlar'dan Groq/NVIDIA/Özel API anahtarlarını kontrol et.")
        }
    }

    private fun runWeb(query: String) {
        job?.cancel(); setBusy(true); val id = addAssistant("Web araştırılıyor…")
        job = lifecycleScope.launch {
            val report = withTimeoutOrNull(35000) { withContext(Dispatchers.IO) { WebResearch.research(query) { m -> runOnUiThread { status(m); updateAssistant(id,m) } } } }
            finishAnswer(id, report?.directAnswer ?: report?.fallbackAnswer() ?: "Web doğrulaması zaman aşımına uğradı.")
        }
    }

    private fun runLocal(prompt: String, reuseId: String? = null) {
        if (!modelReady) { finishAnswer(reuseId ?: addAssistant(""), "Ayarlar'dan Groq, NVIDIA veya özel API anahtarı ekle ya da yerel GGUF modeli seç."); return }
        if (reuseId == null) job?.cancel()
        setBusy(true); val id = reuseId ?: addAssistant(""); localBuf.clear(); status("Yerel yedek düşünüyor…")
        job = lifecycleScope.launch(Dispatchers.Default) {
            val ok = withTimeoutOrNull(70000) { engine.sendUserPrompt(prompt).collect { token -> localBuf.append(token); withContext(Dispatchers.Main) { updateAssistant(id, localBuf.toString()) } }; true } == true
            withContext(Dispatchers.Main) { finishAnswer(id, sanitize(localBuf.toString()).ifBlank { if(ok) "Yanıt üretilemedi." else "Yerel model zaman aşımına uğradı." }) }
        }
    }

    private fun finishAnswer(id: String, text: String) { updateAssistant(id, text); setBusy(false); status("Hazır"); speak(text) }

    private fun ensureCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchCamera() else cameraPermission.launch(Manifest.permission.CAMERA)
    }
    private fun launchCamera() { runCatching { cameraLauncher.launch(Intent(this, CameraActivity::class.java)) }.onFailure { toast("Kamera açılamadı: ${it.message}") } }
    private fun onPhotoCaptured(uri: Uri) {
        addAssistant("Fotoğraf çekildi. 4K otomatik iyileştirme hazırlanıyor…")
        if (!secrets.has("gemini_api_key")) { addAssistant("Orijinal fotoğraf Galeri'ye kaydedildi. 4K AI iyileştirme için Ayarlar'dan Gemini API anahtarı ekle."); return }
        if (!prefs.getBoolean("auto_enhance", true)) { addAssistant("Orijinal fotoğraf kaydedildi. Otomatik AI iyileştirme Ayarlar'da kapalı."); return }
        setBusy(true); job = lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching {
                val bytes = MediaStudio.readBytes(this@MainActivity, uri)
                val mime = contentResolver.getType(uri) ?: "image/jpeg"
                val prompt = "Bu fotoğrafı profesyonel kamera çıktısı gibi iyileştir. Kompozisyonu ve gerçek içeriği koru; yüzleri ve nesneleri değiştirme. Gürültüyü azalt, netliği doğal biçimde artır, beyaz dengesi, dinamik aralık, pozlama ve renkleri düzelt. Yapay detay uydurma. 4K yüksek kaliteli JPEG üret."
                val r = GeminiApi(secrets).generateImage(prompt, bytes, mime, aspect = "", size = "4K")
                MediaStudio.saveImage(this@MainActivity, r.bytes)
            }
            withContext(Dispatchers.Main) {
                setBusy(false); result.onSuccess { addAssistant("4K AI geliştirilmiş fotoğraf Galeri'ye kaydedildi.") }.onFailure { addAssistant("Fotoğraf iyileştirme hatası: ${it.message}. Orijinal fotoğraf korunuyor.") }
            }
        }
    }

    private fun attachFile(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            val r = runCatching {
                val name = queryName(uri).ifBlank { "dosya" }; val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                GeminiAgent.Attachment(name, mime, MediaStudio.readBytes(this@MainActivity, uri))
            }
            withContext(Dispatchers.Main) { r.onSuccess { pendingAttachment = it; attachButton.text = "Dosya • 1"; status("${it.name} eklendi") }.onFailure { toast("Dosya eklenemedi: ${it.message}") } }
        }
    }

    private fun showSettings() {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36,16,36,20) }
        val scroll = ScrollView(this).apply { addView(wrap) }
        fun label(t: String) { wrap.addView(TextView(this).apply { text=t; textSize=13f; setPadding(0,14,0,2) }) }
        fun field(hint: String, value: String, secret: Boolean = false): EditText = EditText(this).apply {
            this.hint=hint; setText(value); if(secret) inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; wrap.addView(this)
        }
        label("Ana yapay zeka sağlayıcısı")
        val providerIds = arrayOf("auto","groq","nvidia","custom","gemini","local")
        val providerLabels = arrayOf("Otomatik • Groq → NVIDIA → Özel → Gemini → Yerel","Groq","NVIDIA NIM","Özel OpenAI uyumlu API","Gemini (opsiyonel medya/yedek)","Yalnızca yerel model")
        val provider = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, providerLabels)
            setSelection(providerIds.indexOf(providerMode()).coerceAtLeast(0)); wrap.addView(this)
        }

        label("Groq • hızlı ana ajan beyni")
        val groq = field("Groq API key", secrets.get("groq_api_key"), true)
        val groqModel = field("Groq model", secrets.get("groq_model").ifBlank { "openai/gpt-oss-120b" })
        val groqBase = field("Groq API adresi", secrets.get("groq_base_url").ifBlank { "https://api.groq.com/openai/v1" })

        label("NVIDIA NIM • ücretsiz endpoint destekli ajan beyni")
        val nvidia = field("NVIDIA API key", secrets.get("nvidia_api_key"), true)
        val nvidiaModel = field("NVIDIA model", secrets.get("nvidia_model").ifBlank { "nvidia/nemotron-3-ultra-550b-a55b" })
        val nvidiaBase = field("NVIDIA API adresi", secrets.get("nvidia_base_url").ifBlank { "https://integrate.api.nvidia.com/v1" })

        label("Gemini • opsiyonel medya/yedek (boş bırakılabilir)")
        val gemini = field("Gemini API key", secrets.get("gemini_api_key"), true)
        val geminiChat = field("Gemini sohbet modeli", secrets.get("gemini_chat_model").ifBlank { "gemini-3.8-flash" })
        val geminiImage = field("Gemini görsel modeli", secrets.get("gemini_image_model").ifBlank { "gemini-3.1-flash-image" })
        val geminiVideo = field("Gemini video modeli", secrets.get("gemini_video_model").ifBlank { "veo-3.1-generate-preview" })
        val geminiMusic = field("Gemini müzik modeli", secrets.get("gemini_music_model").ifBlank { "lyria-3.5" })
        val geminiBase = field("Gemini API adresi", secrets.get("gemini_base_url").ifBlank { "https://generativelanguage.googleapis.com/v1beta" })

        label("Özel • gelecekte başka API için APK değiştirmeden")
        val custom = field("Özel API key", secrets.get("custom_api_key"), true)
        val customBase = field("OpenAI uyumlu base URL (örn. https://.../v1)", secrets.get("custom_base_url"))
        val customModel = field("Model ID", secrets.get("custom_model"))

        label("Araç bağlantıları")
        val github = field("GitHub token (isteğe bağlı)", secrets.get("github_token"), true)
        val pcUrl = field("PC Bridge URL (örn. http://192.168.1.5:8765)", secrets.get("pc_bridge_url"))
        val pcToken = field("PC Bridge token", secrets.get("pc_bridge_token"), true)
        val autoEnhance = CheckBox(this).apply { text = "Kamera fotoğraflarını Gemini ile otomatik 4K geliştir"; isChecked = prefs.getBoolean("auto_enhance", true); wrap.addView(this) }

        AlertDialog.Builder(this).setTitle("Ajan M&G • AI & API Ayarları").setView(scroll)
            .setPositiveButton("Kaydet ve Test Et") { _, _ ->
                prefs.edit().putString("ai_provider", providerIds[provider.selectedItemPosition]).putBoolean("auto_enhance", autoEnhance.isChecked).apply()
                secrets.put("groq_api_key", groq.text.toString().trim()); secrets.put("groq_model", groqModel.text.toString().trim()); secrets.put("groq_base_url", groqBase.text.toString().trim())
                secrets.put("nvidia_api_key", nvidia.text.toString().trim()); secrets.put("nvidia_model", nvidiaModel.text.toString().trim()); secrets.put("nvidia_base_url", nvidiaBase.text.toString().trim())
                secrets.put("gemini_api_key", gemini.text.toString().trim()); secrets.put("gemini_chat_model", geminiChat.text.toString().trim()); secrets.put("gemini_image_model", geminiImage.text.toString().trim())
                secrets.put("gemini_video_model", geminiVideo.text.toString().trim()); secrets.put("gemini_music_model", geminiMusic.text.toString().trim()); secrets.put("gemini_base_url", geminiBase.text.toString().trim())
                secrets.put("custom_api_key", custom.text.toString().trim()); secrets.put("custom_base_url", customBase.text.toString().trim()); secrets.put("custom_model", customModel.text.toString().trim())
                secrets.put("github_token", github.text.toString().trim()); secrets.put("pc_bridge_url", pcUrl.text.toString().trim()); secrets.put("pc_bridge_token", pcToken.text.toString().trim())
                refreshHeader(); testSelectedProvider()
            }
            .setNeutralButton("PC Bridge'i Kaydet") { _, _ -> exportPcBridge() }
            .setNegativeButton("İptal", null).show()
    }

    private fun exportPcBridge() {
        lifecycleScope.launch(Dispatchers.IO) {
            val r = runCatching {
                val b = assets.open("ajan_mg_pc_bridge.py").use { it.readBytes() }; MediaStudio.saveDocument(this@MainActivity,b,"ajan_mg_pc_bridge.py","text/x-python")
                val readme = assets.open("ajan_mg_pc_bridge_README.txt").use { it.readBytes() }; MediaStudio.saveDocument(this@MainActivity,readme,"ajan_mg_pc_bridge_README.txt","text/plain")
            }
            withContext(Dispatchers.Main) { r.onSuccess { addAssistant("PC Bridge ve kurulum notu Belgeler/Ajan M&G klasörüne kaydedildi.") }.onFailure { toast("Bridge kaydedilemedi: ${it.message}") } }
        }
    }

    private fun testSelectedProvider() {
        val brain = cloudPlan(null).firstOrNull()
        if (brain == null) { refreshHeader(); if (providerMode() != "local") toast("Aktif bulut API anahtarı yok") ; return }
        status("${brain.label} bağlantısı test ediliyor…")
        lifecycleScope.launch(Dispatchers.IO) {
            val r = runCatching {
                if (brain.type == "gemini") GeminiApi(secrets).testConnection()
                else OpenAiCompatibleApi(brain.config!!).testConnection()
            }
            withContext(Dispatchers.Main) {
                r.onSuccess { status("Hazır • AI + Ajan"); toast("${brain.label} bağlantısı başarılı") }
                    .onFailure { status("${brain.label} bağlantı hatası"); addAssistant("${brain.label} API bağlantısı test edilemedi: ${it.message}") }
            }
        }
    }

    private fun refreshHeader() {
        val mode = providerMode()
        val cloud = when (mode) {
            "groq" -> if (secrets.has("groq_api_key")) "Groq • ${groqConfig().model}" else "Groq • API key bekliyor"
            "nvidia" -> if (secrets.has("nvidia_api_key")) "NVIDIA • ${nvidiaConfig().model}" else "NVIDIA • API key bekliyor"
            "gemini" -> if (secrets.has("gemini_api_key")) "Gemini • ${secrets.get("gemini_chat_model").ifBlank { "varsayılan" }}" else "Gemini • API key bekliyor"
            "custom" -> if (secrets.has("custom_api_key")) "Özel API • ${customConfig().model}" else "Özel API • ayar bekliyor"
            "local" -> "Yerel AI modu"
            else -> {
                val names = mutableListOf<String>(); if (secrets.has("groq_api_key")) names += "Groq"; if (secrets.has("nvidia_api_key")) names += "NVIDIA"; if (secrets.has("custom_api_key")) names += "Özel"; if (secrets.has("gemini_api_key")) names += "Gemini"
                if (names.isEmpty()) "Otomatik • API key bekliyor" else "Otomatik • ${names.joinToString(" → ")}"
            }
        }
        val local = if (modelReady) "yerel yedek hazır" else "yerel yedek isteğe bağlı"
        modelTv.text = "$cloud  •  $local"
        status(if (hasAnyBrain()) "Hazır • AI + Ajan" else "Ayarlar'dan API key ekle veya yerel model seç")
    }

    private fun hasAnyBrain(): Boolean = secrets.has("groq_api_key") || secrets.has("nvidia_api_key") || secrets.has("custom_api_key") || secrets.has("gemini_api_key") || modelReady

    private fun loadSelectedModel(uri: Uri) { setBusy(true); lifecycleScope.launch(Dispatchers.IO) {
        val r = runCatching {
            val meta = contentResolver.openInputStream(uri)?.use { GgufMetadataReader.create().readStructuredMetadata(it) } ?: error("GGUF okunamadı")
            val f = contentResolver.openInputStream(uri)?.use { ensureModelFile(meta.filename()+".gguf", it) } ?: error("Model kopyalanamadı")
            engine.loadModel(f.path); prefs.edit().putString("model_path",f.path).apply(); Pair(f,meta)
        }
        withContext(Dispatchers.Main) { setBusy(false); r.onSuccess { modelReady=true; refreshHeader(); toast("Yerel yedek model hazır") }.onFailure { toast("Model hatası: ${it.message}") } }
    } }

    private fun autoLoadModel() {
        if (!engineReady) return
        val f = prefs.getString("model_path",null)?.let(::File)?.takeIf { it.exists() } ?: return
        lifecycleScope.launch(Dispatchers.IO) { runCatching { engine.loadModel(f.path) }.onSuccess { withContext(Dispatchers.Main) { modelReady=true; refreshHeader() } } }
    }
    private suspend fun ensureModelFile(name:String,input:InputStream):File=withContext(Dispatchers.IO){ File(filesDir,"models").apply{mkdirs()}.resolve(name).also{if(!it.exists()||it.length()==0L)FileOutputStream(it).use{out->input.copyTo(out)}} }

    private fun ensureMic() {
        if (!hasAnyBrain()) return toast("Önce Ayarlar'dan bir API key ekle veya yerel model seç.")
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }
    private fun startListening() {
        if (listening || isBusy()) return
        recognizer?.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this); recognizer?.setRecognitionListener(object:RecognitionListener{
            override fun onReadyForSpeech(p:Bundle?){listening=true;status(if(liveMode)"Canlı • dinliyorum" else "Dinliyorum")}
            override fun onBeginningOfSpeech(){}; override fun onRmsChanged(r:Float){}; override fun onBufferReceived(b:ByteArray?){}; override fun onEndOfSpeech(){listening=false}
            override fun onError(e:Int){listening=false;if(liveMode)Handler(Looper.getMainLooper()).postDelayed({if(liveMode&&!isBusy())startListening()},900)else status("Hazır")}
            override fun onResults(r:Bundle?){listening=false;val s=r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty();if(s.isNotBlank()){userInputEt.setText(s);submit()}else if(liveMode)startListening()}
            override fun onPartialResults(p:Bundle?){}; override fun onEvent(t:Int,p:Bundle?){}
        })
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"tr-TR");putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3)})
    }
    private fun setupTts(){tts=TextToSpeech(this){s->if(s==TextToSpeech.SUCCESS){ttsReady=(tts?.setLanguage(Locale("tr","TR"))?:-1)>=0;tts?.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){override fun onStart(id:String?){};override fun onDone(id:String?){restartLive()};override fun onError(id:String?){restartLive()}})}}}
    private fun speak(text:String){if(!liveMode)return;val s=text.replace(Regex("https?://\\S+"),"").replace(Regex("\\s+")," ").take(1800);recognizer?.cancel();listening=false;if(ttsReady)tts?.speak(s,TextToSpeech.QUEUE_FLUSH,null,"v81_${System.currentTimeMillis()}")else restartLive()}
    private fun restartLive(){if(liveMode)runOnUiThread{Handler(Looper.getMainLooper()).postDelayed({if(liveMode&&!isBusy())startListening()},450)}}
    private fun stopLive(){liveMode=false;liveButton.text="Canlı Asistan";recognizer?.cancel();tts?.stop();listening=false;status("Hazır")}

    private fun restoreMessages(){store.loadMessages().forEach{messages+=Message(it.id,it.content,it.isUser)};adapter.notifyDataSetChanged();if(messages.isNotEmpty())messagesRv.scrollToPosition(messages.lastIndex)}
    private fun addUser(t:String)=addMessage(t,true); private fun addAssistant(t:String)=addMessage(t,false)
    private fun addMessage(t:String,user:Boolean):String{val id=UUID.randomUUID().toString();messages+=Message(id,t,user);store.saveMessage(id,t,user);adapter.notifyItemInserted(messages.lastIndex);messagesRv.scrollToPosition(messages.lastIndex);return id}
    private fun updateAssistant(id:String,t:String){val i=messages.indexOfFirst{it.id==id};if(i<0)return;messages[i]=messages[i].copy(content=t);store.updateMessage(id,t);adapter.notifyItemChanged(i);messagesRv.scrollToPosition(i)}
    private fun setBusy(v:Boolean){progress.visibility=if(v)View.VISIBLE else View.GONE;sendFab.isEnabled=!v;cameraButton.isEnabled=!v;attachButton.isEnabled=!v;liveButton.isEnabled=!v}
    private fun isBusy()=progress.visibility==View.VISIBLE; private fun status(t:String){statusTv.text=t}; private fun toast(t:String){Toast.makeText(this,t,Toast.LENGTH_SHORT).show()}
    private fun queryName(uri:Uri):String{contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())return it.getString(0).orEmpty()};return uri.lastPathSegment.orEmpty()}
    private fun sanitize(s:String)=s.trim().replace(Regex("(?i)^(assistant|asistan|ajan m&g)\\s*:\\s*"),"").take(7000)
    private fun stamp()=SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(Date())

    private fun writeBackup(uri:Uri){lifecycleScope.launch(Dispatchers.IO){val r=runCatching{contentResolver.openOutputStream(uri,"wt")?.use{it.write(store.exportJson().toByteArray())}?:error("Yazılamadı")};withContext(Dispatchers.Main){r.onSuccess{addAssistant("Hafıza ve gelişim yedeği kaydedildi. API anahtarları güvenlik nedeniyle yedeğe dahil edilmedi.")}.onFailure{toast("Yedek hatası: ${it.message}")}}}}
    private fun restoreBackup(uri:Uri){lifecycleScope.launch(Dispatchers.IO){val r=runCatching{val raw=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:error("Okunamadı");store.importJson(raw)};withContext(Dispatchers.Main){r.onSuccess{messages.clear();restoreMessages();addAssistant("Yedek geri yüklendi.")}.onFailure{toast("Geri yükleme hatası: ${it.message}")}}}}

    override fun onStop(){recognizer?.cancel();listening=false;super.onStop()}
    override fun onDestroy(){job?.cancel();recognizer?.destroy();tts?.shutdown();store.close();if(::engine.isInitialized)engine.destroy();super.onDestroy()}
}

fun GgufMetadata.filename() = basic.name?.let { n -> basic.sizeLabel?.let { "$n-$it" } ?: n }
    ?: architecture?.architecture?.let { a -> basic.uuid?.let { "$a-$it" } ?: "$a-${System.currentTimeMillis()}" }
    ?: "model-${System.currentTimeMillis()}"
