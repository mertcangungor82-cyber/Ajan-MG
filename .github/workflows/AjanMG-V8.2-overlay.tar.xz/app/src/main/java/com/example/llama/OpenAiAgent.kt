package com.example.llama

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OpenAiAgent(
    private val context: Context,
    private val store: AgentStore,
    private val secrets: SecureSecrets,
    private val config: OpenAiProviderConfig,
    private val progress: (String) -> Unit = {}
) {
    private val api = OpenAiCompatibleApi(config)
    private val remote = RemoteTools(context, secrets)

    suspend fun respond(text: String, attachment: GeminiAgent.Attachment? = null): String = withContext(Dispatchers.IO) {
        if (config.apiKey.isBlank()) error("${config.label} API anahtarı yok.")
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", systemPrompt()))
            .put(JSONObject().put("role", "user").put("content", buildUserPrompt(text, attachment)))
        var finalText = ""
        repeat(8) { turn ->
            progress(if (turn == 0) "${config.label} düşünüyor…" else "Ajan araçları çalışıyor…")
            val step = api.agentStep(messages, toolDeclarations())
            messages.put(step.message)
            if (step.call == null) {
                finalText = step.text
                return@withContext finalText.ifBlank { "İşlem tamamlandı." }
            }
            val result = runCatching { executeTool(step.call, text) }
                .onSuccess { store.increment("metric_tool_${step.call.name}") }
                .getOrElse { "Hata: ${it.message}" }
            messages.put(
                JSONObject()
                    .put("role", "tool")
                    .put("tool_call_id", step.call.id)
                    .put("content", result)
            )
        }
        finalText.ifBlank { "Ajan araç zinciri sınırına ulaştı. İsteği daha küçük bir adıma bölerek tekrar dene." }
    }

    private fun buildUserPrompt(text: String, attachment: GeminiAgent.Attachment?): String {
        val history = store.conversationContext(8)
        val memory = store.getValue("memory")
        return buildString {
            append(text)
            if (attachment != null) {
                append("\n\n[EK DOSYA: ").append(attachment.name).append(" • ").append(attachment.mime).append(']')
                if (isTextAttachment(attachment.mime)) {
                    append("\n").append(String(attachment.bytes, Charsets.UTF_8).take(24000))
                } else {
                    append("\nBu sağlayıcıya ikili dosya doğrudan gönderilmedi. Dosyanın içeriği gerekiyorsa Gemini sağlayıcısını seç veya metin/CSV dosyası kullan.")
                }
            }
            if (history.isNotBlank()) append("\n\n[SON SOHBET]\n").append(history.takeLast(2600))
            if (memory.isNotBlank()) append("\n\n[KİŞİSEL HAFIZA]\n").append(memory.takeLast(3500))
            val rules = store.languageContext(); if (rules.isNotBlank()) append("\n\n[DAVRANIŞ KURALLARI]\n").append(rules)
        }
    }

    private fun isTextAttachment(mime: String): Boolean = mime.startsWith("text/") || mime.contains("json") || mime.contains("csv") || mime.contains("xml")

    private fun systemPrompt(): String {
        val user = store.getValue("user_name").ifBlank { "kullanıcı" }
        val assistant = store.getValue("assistant_name").ifBlank { "Ajan M&G" }
        val now = SimpleDateFormat("d MMMM yyyy EEEE HH:mm", Locale("tr", "TR")).format(Date())
        return """
            Sen $assistant adlı kişisel yapay zeka ve eylem ajanısın. Kullanıcı: $user. Şu an: $now. Ana sağlayıcı: ${config.label} / ${config.model}.
            Türkçe konuş; doğal, doğru ve işe dönük ol. Güncel bilgi gerekiyorsa web_search aracını kullan ve uydurma.
            Kullanıcının isteği araçla yapılabiliyorsa yalnızca anlatmak yerine uygun aracı çağır. Dosya üretiminde create_excel/create_pdf; görselde generate_image; videoda generate_video; müzikte generate_music kullan.
            Görsel, video ve müzik üretim araçları ayrı Gemini medya anahtarını kullanır. Bu anahtar yoksa bunu açıkça söyle ve işlemi başarılı göstermeye çalışma.
            Bilgisayar işi için pc_command; GitHub ve APK geliştirme işi için github_get_file, github_put_file, github_runs ve github_dispatch araçlarını kullan. İnternette bir sayfayı açmak için open_url kullan.
            Finansal ödeme, satın alma, 3D Secure, CAPTCHA, şifre veya kimlik doğrulama adımını kullanıcı yerine aşmaya çalışma; ilgili sayfayı açıp kullanıcıdan son onayı iste.
            Kalıcı kişisel tercih açıkça verilirse remember aracını kullan. Araç sonucunu değiştirmeden özetle. Başarısız bir aracı başarılı olmuş gibi gösterme.
        """.trimIndent()
    }

    private suspend fun executeTool(call: OpenAiCompatibleApi.FunctionCall, original: String): String {
        val a = call.args
        return when (call.name) {
            "web_search" -> {
                progress("Web araştırılıyor…")
                val r = WebResearch.research(a.optString("query")) { progress(it) }
                r.directAnswer ?: r.fallbackAnswer()
            }
            "remember" -> { store.appendMemory(a.optString("text")); "Kalıcı hafızaya kaydedildi." }
            "create_excel" -> {
                progress("Excel hazırlanıyor…")
                val uri = OfficeStudio.createXlsx(context, a.optString("title", "Ajan M&G Tablo"), a.optString("csv"))
                "Excel oluşturuldu ve telefona kaydedildi: $uri"
            }
            "create_pdf" -> {
                progress("PDF hazırlanıyor…")
                val uri = OfficeStudio.createPdf(context, a.optString("title", "Ajan M&G Belge"), a.optString("body"))
                "PDF oluşturuldu ve telefona kaydedildi: $uri"
            }
            "generate_image" -> {
                requireGeminiMedia()
                progress("4K görsel üretiliyor…")
                val r = GeminiApi(secrets).generateImage(a.optString("prompt"), aspect = a.optString("aspect_ratio", "1:1"), size = a.optString("size", "4K"))
                val uri = MediaStudio.saveImage(context, r.bytes)
                "Görsel üretildi ve Galeri'ye kaydedildi: $uri"
            }
            "generate_video" -> {
                requireGeminiMedia()
                progress("Video üretiliyor…")
                val r = GeminiApi(secrets).generateVideo(a.optString("prompt"), a.optString("aspect_ratio", "9:16"), a.optString("resolution", "1080p"))
                val uri = MediaStudio.saveVideo(context, r.bytes)
                "Video üretildi ve Galeri'ye kaydedildi: $uri"
            }
            "generate_music" -> {
                requireGeminiMedia()
                progress("Müzik üretiliyor…")
                val r = GeminiApi(secrets).generateMusic(a.optString("prompt"), a.optBoolean("full_song", true))
                val uri = MediaStudio.saveMusic(context, r.bytes)
                "Müzik üretildi ve telefona kaydedildi: $uri${if (r.text.isNotBlank()) "\nSözler/özet: ${r.text.take(1200)}" else ""}"
            }
            "open_url" -> remote.openUrl(a.optString("url"))
            "pc_command" -> {
                if (!explicitAction(original)) return "PC komutu için kullanıcının açık bir eylem talebi gerekli."
                remote.pcCommand(a.optString("command"), a.optJSONObject("payload") ?: JSONObject())
            }
            "github_get_file" -> remote.githubGetFile(a.optString("repo"), a.optString("path"), a.optString("ref", "main"))
            "github_put_file" -> {
                if (!explicitAction(original)) return "GitHub yazma işlemi için açık kullanıcı talebi gerekli."
                remote.githubPut(a.optString("repo"), a.optString("path"), a.optString("content"), a.optString("message"), a.optString("sha").ifBlank { null })
            }
            "github_runs" -> remote.githubRuns(a.optString("repo"))
            "github_dispatch" -> {
                if (!explicitAction(original)) return "Workflow çalıştırmak için açık kullanıcı talebi gerekli."
                remote.githubDispatch(a.optString("repo"), a.optString("workflow"), a.optString("ref", "main"))
            }
            "current_time" -> SimpleDateFormat("d MMMM yyyy EEEE HH:mm:ss", Locale("tr", "TR")).format(Date())
            else -> "Bilinmeyen araç: ${call.name}"
        }
    }

    private fun requireGeminiMedia() {
        if (!secrets.has("gemini_api_key")) error("Görsel/video/müzik için Ayarlar'daki ayrı Gemini API anahtarı gerekli.")
    }

    private fun explicitAction(text: String): Boolean {
        val l = text.lowercase(Locale("tr", "TR"))
        return listOf("yap", "oluştur", "çalıştır", "aç", "kaydet", "gönder", "değiştir", "güncelle", "kur", "derle", "hazırla", "sil").any { l.contains(it) }
    }

    private fun toolDeclarations(): JSONArray {
        fun schema(vararg fields: Pair<String, String>) = JSONObject().put("type", "object").put("properties", JSONObject().apply { fields.forEach { (n,t) -> put(n, JSONObject().put("type", t.lowercase())) } })
        fun decl(name: String, description: String, params: JSONObject, required: List<String> = emptyList()) =
            JSONObject().put("name", name).put("description", description).put("parameters", params.apply { if (required.isNotEmpty()) put("required", JSONArray(required)) })
        return JSONArray()
            .put(decl("web_search", "Güncel, sayısal veya internette doğrulanması gereken bilgi araştır.", schema("query" to "string"), listOf("query")))
            .put(decl("remember", "Kullanıcının kalıcı kişisel tercihini veya önemli bilgisini kaydet.", schema("text" to "string"), listOf("text")))
            .put(decl("create_excel", "CSV biçimindeki veriden gerçek XLSX Excel dosyası oluştur ve telefona kaydet.", schema("title" to "string", "csv" to "string"), listOf("title","csv")))
            .put(decl("create_pdf", "Başlık ve metinden PDF oluştur ve telefona kaydet.", schema("title" to "string", "body" to "string"), listOf("title","body")))
            .put(decl("generate_image", "Gemini medya API ile görsel üret ve Galeri'ye kaydet. size: 1K,2K,4K; aspect_ratio ör. 1:1,9:16,16:9.", schema("prompt" to "string", "aspect_ratio" to "string", "size" to "string"), listOf("prompt")))
            .put(decl("generate_video", "Gemini/Veo medya API ile video üret. resolution 720p,1080p,4k; aspect_ratio 9:16 veya 16:9.", schema("prompt" to "string", "aspect_ratio" to "string", "resolution" to "string"), listOf("prompt")))
            .put(decl("generate_music", "Gemini/Lyria medya API ile müzik veya tam şarkı üret.", schema("prompt" to "string", "full_song" to "boolean"), listOf("prompt")))
            .put(decl("open_url", "Web sayfası veya arama sonucunu telefonda aç.", schema("url" to "string"), listOf("url")))
            .put(decl("pc_command", "Kullanıcının kendi bilgisayarındaki Ajan M&G PC Bridge'e komut gönder. command ör: list_files,read_file,write_file,open_app,open_url,run_command; payload JSON nesnesidir.", JSONObject().put("type","object").put("properties",JSONObject().put("command",JSONObject().put("type","string")).put("payload",JSONObject().put("type","object"))).put("required",JSONArray(listOf("command","payload")))))
            .put(decl("github_get_file", "GitHub deposundaki metin dosyasını ve güncelleme SHA'sını oku.", schema("repo" to "string", "path" to "string", "ref" to "string"), listOf("repo","path")))
            .put(decl("github_put_file", "GitHub deposunda metin dosyası oluştur veya güncelle. SHA verilmezse araç mevcut dosyanın SHA'sını otomatik bulur.", schema("repo" to "string", "path" to "string", "content" to "string", "message" to "string", "sha" to "string"), listOf("repo","path","content")))
            .put(decl("github_runs", "GitHub Actions son workflow çalışmalarını ve durumlarını oku.", schema("repo" to "string"), listOf("repo")))
            .put(decl("github_dispatch", "GitHub Actions workflow_dispatch çalıştır.", schema("repo" to "string", "workflow" to "string", "ref" to "string"), listOf("repo","workflow")))
            .put(decl("current_time", "Telefonun güncel tarih ve saatini al.", schema()))
    }
}
