package com.example.llama

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

data class StoredMessage(
    val id: String,
    val content: String,
    val isUser: Boolean,
    val createdAt: Long
)

class AgentStore(context: Context) :
    SQLiteOpenHelper(context, "ajan_mg.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE messages(id TEXT PRIMARY KEY, content TEXT NOT NULL, is_user INTEGER NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE language(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, wrong_text TEXT, right_text TEXT, sample TEXT, created_at INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun getValue(key: String): String {
        readableDatabase.rawQuery("SELECT v FROM kv WHERE k=?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else ""
        }
    }

    fun setValue(key: String, value: String) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO kv(k,v) VALUES(?,?)",
            arrayOf<Any?>(key, value)
        )
    }


    fun increment(key: String): Long {
        val v = (getValue(key).toLongOrNull() ?: 0L) + 1
        setValue(key, v.toString())
        return v
    }

    fun selfImproveEnabled(): Boolean {
        val v = getValue("self_improve")
        if (v.isBlank()) { setValue("self_improve", "1"); return true }
        return v != "0"
    }

    fun setSelfImprove(enabled: Boolean) = setValue("self_improve", if (enabled) "1" else "0")

    fun developmentSummary(): String = "Kendini geliştirme modu ${if (selfImproveEnabled()) "açık" else "kapalı"}. Öğrenilmiş düzeltme: ${getValue("metric_corrections").ifBlank { "0" }}, başarılı web doğrulaması: ${getValue("metric_web_success").ifBlank { "0" }}, başarısız web denemesi: ${getValue("metric_web_fail").ifBlank { "0" }}."

    fun appendMemory(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val old = getValue("memory")
        val line = "• $clean"
        if (old.lines().any { it.trim().equals(line, true) }) return
        setValue("memory", (old + "\n" + line).trim().takeLast(30000))
    }

    fun saveMessage(id: String, content: String, isUser: Boolean) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO messages(id,content,is_user,created_at) VALUES(?,?,?,?)",
            arrayOf<Any?>(id, content, if (isUser) 1 else 0, System.currentTimeMillis())
        )
    }

    fun updateMessage(id: String, content: String) {
        writableDatabase.execSQL(
            "UPDATE messages SET content=? WHERE id=?",
            arrayOf<Any?>(content, id)
        )
    }

    fun loadMessages(limit: Int = 200): List<StoredMessage> {
        val out = mutableListOf<StoredMessage>()
        readableDatabase.rawQuery(
            "SELECT id,content,is_user,created_at FROM messages ORDER BY created_at DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += StoredMessage(c.getString(0), c.getString(1), c.getInt(2) == 1, c.getLong(3))
            }
        }
        return out.reversed()
    }

    fun conversationContext(limit: Int = 4): String {
        val bad = listOf("kaynaklar karşılaştırılıyor", "doğal türkçe üslup örnekleri", "devami", "galatasaray.org facebook")
        val recent = loadMessages(20).dropLast(1).filter { m ->
            val l = m.content.lowercase()
            m.content.isNotBlank() && m.content.length < 1000 && bad.none { l.contains(it) }
        }.takeLast(limit)
        return recent.joinToString("\n") { (if (it.isUser) "Kullanıcı" else "Ajan") + ": " + it.content.take(320) }.takeLast(1400)
    }

    fun clearMessages() {
        writableDatabase.execSQL("DELETE FROM messages")
    }

    fun addCorrection(wrong: String, right: String) {
        increment("metric_corrections")
        writableDatabase.execSQL(
            "INSERT INTO language(kind,wrong_text,right_text,sample,created_at) VALUES('correction',?,?,NULL,?)",
            arrayOf<Any?>(wrong.trim(), right.trim(), System.currentTimeMillis())
        )
    }

    fun addLanguageSample(sample: String) {
        val s = sample.replace(Regex("\\s+"), " ").trim().take(420)
        if (s.length < 45) return
        writableDatabase.execSQL(
            "INSERT INTO language(kind,wrong_text,right_text,sample,created_at) VALUES('sample',NULL,NULL,?,?)",
            arrayOf<Any?>(s, System.currentTimeMillis())
        )
        writableDatabase.execSQL(
            """DELETE FROM language WHERE kind='sample' AND id NOT IN
               (SELECT id FROM language WHERE kind='sample' ORDER BY created_at DESC LIMIT 48)"""
        )
    }

    fun addLanguageRule(rule: String) {
        val r = rule.replace(Regex("\\s+"), " ").trim().take(360)
        if (r.length < 12) return
        readableDatabase.rawQuery("SELECT 1 FROM language WHERE kind='rule' AND sample=? LIMIT 1", arrayOf(r)).use { if (it.moveToFirst()) return }
        writableDatabase.execSQL("INSERT INTO language(kind,wrong_text,right_text,sample,created_at) VALUES('rule',NULL,NULL,?,?)", arrayOf<Any?>(r, System.currentTimeMillis()))
    }

    fun languageContext(): String {
        val corrections = mutableListOf<String>()
        val rules = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT kind,wrong_text,right_text,sample FROM language ORDER BY created_at DESC LIMIT 40", null).use { c ->
            while (c.moveToNext()) when (c.getString(0)) {
                "correction" -> if (corrections.size < 8) corrections += "${c.getString(1)} → ${c.getString(2)}"
                "rule" -> if (rules.size < 10) rules += c.getString(3).orEmpty()
            }
        }
        return buildString {
            append("Doğal ve kısa Türkçe kullan; soruyu tekrar etme; bilmediğini uydurma; sayı, tarih, skor ve isimleri değiştirme.")
            if (rules.isNotEmpty()) append("\nÖğrenilmiş kurallar: ").append(rules.joinToString(" | "))
            if (corrections.isNotEmpty()) append("\nKullanıcı düzeltmeleri: ").append(corrections.joinToString(" | "))
        }.take(1200)
    }

    fun exportJson(): String {
        val root = JSONObject()
        root.put("format", "AjanMG-backup-v2")
        root.put("memory", getValue("memory"))
        root.put("user_name", getValue("user_name"))
        root.put("assistant_name", getValue("assistant_name"))
        root.put("last_language_sync", getValue("last_language_sync"))
        root.put("tr_seed_v2", getValue("tr_seed_v2"))
        root.put("tr_rules_v3", getValue("tr_rules_v3"))
        root.put("tr_rule_index", getValue("tr_rule_index"))
        root.put("self_improve", getValue("self_improve"))
        root.put("metric_corrections", getValue("metric_corrections"))
        root.put("metric_web_success", getValue("metric_web_success"))
        root.put("metric_web_fail", getValue("metric_web_fail"))

        val msgs = JSONArray()
        loadMessages(500).forEach {
            msgs.put(JSONObject().put("id", it.id).put("content", it.content).put("isUser", it.isUser).put("createdAt", it.createdAt))
        }
        root.put("messages", msgs)

        val lang = JSONArray()
        readableDatabase.rawQuery(
            "SELECT kind,wrong_text,right_text,sample,created_at FROM language ORDER BY created_at",
            null
        ).use { c ->
            while (c.moveToNext()) {
                lang.put(
                    JSONObject().put("kind", c.getString(0)).put("wrong", c.getString(1))
                        .put("right", c.getString(2)).put("sample", c.getString(3)).put("createdAt", c.getLong(4))
                )
            }
        }
        root.put("language", lang)
        return root.toString(2)
    }

    fun importJson(raw: String) {
        val root = JSONObject(raw)
        val db = writableDatabase
        db.beginTransaction()
        try {
            setValue("memory", root.optString("memory"))
            setValue("user_name", root.optString("user_name"))
            setValue("assistant_name", root.optString("assistant_name"))
            setValue("last_language_sync", root.optString("last_language_sync"))
            setValue("tr_seed_v2", root.optString("tr_seed_v2"))
            setValue("tr_rules_v3", root.optString("tr_rules_v3"))
            setValue("tr_rule_index", root.optString("tr_rule_index"))
            setValue("self_improve", root.optString("self_improve", "1"))
            setValue("metric_corrections", root.optString("metric_corrections"))
            setValue("metric_web_success", root.optString("metric_web_success"))
            setValue("metric_web_fail", root.optString("metric_web_fail"))
            db.execSQL("DELETE FROM messages")
            db.execSQL("DELETE FROM language")

            val msgs = root.optJSONArray("messages") ?: JSONArray()
            for (i in 0 until msgs.length()) {
                val m = msgs.getJSONObject(i)
                db.execSQL(
                    "INSERT OR REPLACE INTO messages(id,content,is_user,created_at) VALUES(?,?,?,?)",
                    arrayOf<Any?>(m.optString("id"), m.optString("content"), if (m.optBoolean("isUser")) 1 else 0, m.optLong("createdAt", System.currentTimeMillis()))
                )
            }

            val lang = root.optJSONArray("language") ?: JSONArray()
            for (i in 0 until lang.length()) {
                val x = lang.getJSONObject(i)
                db.execSQL(
                    "INSERT INTO language(kind,wrong_text,right_text,sample,created_at) VALUES(?,?,?,?,?)",
                    arrayOf<Any?>(x.optString("kind"), x.optString("wrong").ifBlank { null }, x.optString("right").ifBlank { null }, x.optString("sample").ifBlank { null }, x.optLong("createdAt", System.currentTimeMillis()))
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }
}
