package com.example.llama

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object OfficeStudio {
    fun createXlsx(context: Context, title: String, csv: String): android.net.Uri {
        val rows = csv.lines().filter { it.isNotBlank() }.map { splitCsv(it) }
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            fun entry(path: String, text: String) {
                zip.putNextEntry(ZipEntry(path)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry()
            }
            entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${xml(title.take(28).ifBlank { "Sayfa1" })}" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            val sheet = buildString {
                append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
                rows.forEachIndexed { ri, row ->
                    append("<row r=\"").append(ri + 1).append("\">")
                    row.forEachIndexed { ci, value ->
                        val ref = col(ci) + (ri + 1)
                        value.toDoubleOrNull()?.let { append("<c r=\"").append(ref).append("\"><v>").append(it).append("</v></c>") }
                            ?: append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t>").append(xml(value)).append("</t></is></c>")
                    }
                    append("</row>")
                }
                append("</sheetData></worksheet>")
            }
            entry("xl/worksheets/sheet1.xml", sheet)
        }
        return MediaStudio.saveDocument(context, out.toByteArray(), safe(title, "xlsx"), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    }

    fun createPdf(context: Context, title: String, body: String): android.net.Uri {
        val doc = PdfDocument(); val paint = Paint().apply { textSize = 14f; isAntiAlias = true }
        val titlePaint = Paint(paint).apply { textSize = 22f; isFakeBoldText = true }
        val lines = wrap(body, 82)
        var index = 0; var pageNo = 1
        while (index < lines.size || pageNo == 1) {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(1240, 1754, pageNo).create())
            val c = page.canvas; c.drawText(title.take(70), 70f, 90f, titlePaint)
            var y = 145f
            repeat(58) {
                if (index >= lines.size) return@repeat
                c.drawText(lines[index++], 70f, y, paint); y += 26f
            }
            doc.finishPage(page); pageNo++
            if (index >= lines.size) break
        }
        val out = ByteArrayOutputStream(); doc.writeTo(out); doc.close()
        return MediaStudio.saveDocument(context, out.toByteArray(), safe(title, "pdf"), "application/pdf")
    }

    fun createText(context: Context, title: String, body: String): android.net.Uri =
        MediaStudio.saveDocument(context, body.toByteArray(Charsets.UTF_8), safe(title, "txt"), "text/plain")

    private fun splitCsv(line: String): List<String> {
        val sep = if (line.count { it == ';' } > line.count { it == ',' }) ';' else ','
        val out = mutableListOf<String>(); val cur = StringBuilder(); var quoted = false
        line.forEach { ch -> when { ch == '"' -> quoted = !quoted; ch == sep && !quoted -> { out += cur.toString().trim(); cur.clear() }; else -> cur.append(ch) } }
        out += cur.toString().trim(); return out
    }
    private fun col(i: Int): String { var n = i + 1; var s = ""; while (n > 0) { val r = (n - 1) % 26; s = ('A'.code + r).toChar() + s; n = (n - 1) / 26 }; return s }
    private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun safe(title: String, ext: String) = (title.ifBlank { "AjanMG" }.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").take(60) + ".$ext")
    private fun wrap(text: String, width: Int): List<String> {
        val out = mutableListOf<String>()
        text.lines().forEach { paragraph ->
            var line = ""
            paragraph.split(Regex("\\s+")).forEach { word ->
                if ((line.length + word.length + 1) > width) { out += line; line = word } else line = if (line.isBlank()) word else "$line $word"
            }
            if (line.isNotBlank()) out += line
            if (paragraph.isBlank()) out += ""
        }
        return out.ifEmpty { listOf("") }
    }
}
