package com.example.llama

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.view.Surface
import android.view.TextureView
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class CameraActivity : AppCompatActivity() {
    private lateinit var preview: TextureView
    private lateinit var cameraManager: CameraManager
    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var backgroundThread: HandlerThread? = null
    private var handler: Handler? = null
    private var cameraId: String = ""
    private var sensorOrientation: Int = 0
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)
        preview = findViewById(R.id.camera_preview)
        cameraManager = getSystemService(CameraManager::class.java)
        findViewById<ImageButton>(R.id.camera_close).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.camera_shutter).setOnClickListener { capture() }
        findViewById<TextView>(R.id.camera_hint).text = "Ajan M&G Kamera  •  AI 4K"
        preview.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) { open() }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) = Unit
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit
        }
    }

    override fun onResume() {
        super.onResume()
        backgroundThread = HandlerThread("AjanCamera").also { it.start() }
        handler = Handler(backgroundThread!!.looper)
        if (preview.isAvailable) open()
    }

    override fun onPause() {
        closeCamera()
        backgroundThread?.quitSafely(); backgroundThread = null; handler = null
        super.onPause()
    }

    @SuppressLint("MissingPermission")
    private fun open() {
        if (camera != null || !preview.isAvailable) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { finish(); return }
        runCatching {
            cameraId = chooseCamera()
            val c = cameraManager.getCameraCharacteristics(cameraId)
            sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
            val sizes = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?.getOutputSizes(android.graphics.ImageFormat.JPEG).orEmpty()
            val chosen = sizes.filter { it.width.toLong() * it.height <= 16_000_000L }.maxByOrNull { it.width.toLong() * it.height }
                ?: sizes.maxByOrNull { it.width.toLong() * it.height } ?: error("Kamera çözünürlüğü bulunamadı")
            reader?.close(); reader = ImageReader.newInstance(chosen.width, chosen.height, android.graphics.ImageFormat.JPEG, 2)
            reader?.setOnImageAvailableListener({ r ->
                val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                val bytes = image.planes[0].buffer.let { b -> ByteArray(b.remaining()).also { b.get(it) } }
                image.close(); saveAndFinish(bytes)
            }, handler)
            cameraManager.openCamera(cameraId, stateCallback, handler)
        }.onFailure { toast("Kamera açılamadı: ${it.message}"); finish() }
    }

    private fun chooseCamera(): String {
        val ids = cameraManager.cameraIdList
        return ids.firstOrNull { cameraManager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK }
            ?: ids.firstOrNull() ?: error("Kamera bulunamadı")
    }

    private val stateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(device: CameraDevice) { camera = device; startPreview() }
        override fun onDisconnected(device: CameraDevice) { device.close(); camera = null }
        override fun onError(device: CameraDevice, error: Int) { device.close(); camera = null; runOnUiThread { toast("Kamera hatası: $error"); finish() } }
    }

    private fun startPreview() {
        val device = camera ?: return
        val texture = preview.surfaceTexture ?: return
        texture.setDefaultBufferSize(1920, 1080)
        val surface = Surface(texture)
        val outputs = listOf(surface, reader?.surface ?: return)
        device.createCaptureSession(outputs, object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                if (camera == null) return
                session = s
                val req = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                    addTarget(surface)
                    set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                }.build()
                runCatching { s.setRepeatingRequest(req, null, handler) }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) { runOnUiThread { toast("Kamera önizlemesi başlatılamadı.") } }
        }, handler)
    }

    private fun capture() {
        if (busy) return
        val device = camera ?: return
        val target = reader?.surface ?: return
        busy = true
        val rotation = display?.rotation ?: Surface.ROTATION_0
        val degrees = when (rotation) { Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0 }
        val jpegOrientation = (sensorOrientation + degrees + 360) % 360
        val req = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
            addTarget(target)
            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation)
        }.build()
        runCatching { session?.capture(req, object : CameraCaptureSession.CaptureCallback() {}, handler) }
            .onFailure { busy = false; toast("Fotoğraf çekilemedi: ${it.message}") }
    }

    private fun saveAndFinish(bytes: ByteArray) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, MediaStudio.fileName("AjanMG-Kamera", "jpg"))
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Ajan M&G/Original")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { runOnUiThread { busy = false; toast("Fotoğraf kaydedilemedi.") }; return }
        runCatching { contentResolver.openOutputStream(uri, "w")!!.use { it.write(bytes) } }
            .onSuccess { runOnUiThread { setResult(RESULT_OK, Intent().setData(uri)); finish() } }
            .onFailure { contentResolver.delete(uri, null, null); runOnUiThread { busy = false; toast("Fotoğraf kaydedilemedi: ${it.message}") } }
    }

    private fun closeCamera() { runCatching { session?.close() }; session = null; runCatching { camera?.close() }; camera = null; runCatching { reader?.close() }; reader = null }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
