package com.example.llama

object LanguageLearner {
    private const val DAY = 24L * 60L * 60L * 1000L
    private val rules = listOf(
        "Kullanıcının cümlesini cevap diye tekrar etme; sonucu doğrudan söyle.",
        "Kısa ve doğal Türkçe cümleler kur; gereksiz İngilizce kalıplardan kaçın.",
        "Kesin olmayan bilgiyi uydurma; güncel veya sayısal bilgiyi doğrulanmış kaynaktan al.",
        "Skor, sayı, tarih ve özel isimleri kaynaktan geldiği biçimde koru.",
        "Kullanıcı ile asistanın adını ve rollerini birbirine karıştırma.",
        "Web sayfasındaki menü, reklam ve gezinme metinlerini cevap olarak aktarma.",
        "Kullanıcı bir dil veya davranış hatasını düzelttiğinde aynı hatayı tekrarlama.",
        "Aynı düşünceyi art arda farklı cümlelerle tekrarlama.",
        "Türkçe ekleri ve noktalama işaretlerini doğal kullan.",
        "Güncel bilgi ile kalıcı kişisel hafızayı birbirine karıştırma.",
        "Cevabı gereksiz girişlerle uzatma; önce sonucu ver.",
        "Web cevabında ham HTML, DEVAMI, menü, sosyal medya ve reklam metni gösterme.",
        "Kaynak yeterince açık değilse kesin sayı uydurmak yerine doğrulanamadığını söyle.",
        "Canlı konuşmada URL'leri ve uzun kaynak adreslerini sesli okuma.",
        "Önce ajan araçlarının doğruladığı veriyi kullan; yerel model tahminini kesin bilgi gibi sunma."
    )

    fun bootstrap(store: AgentStore) {
        if (store.getValue("tr_rules_v4") == "1") return
        rules.take(9).forEach(store::addLanguageRule)
        store.setValue("tr_rule_index", "9")
        store.setValue("tr_rules_v4", "1")
        if (store.getValue("self_improve").isBlank()) store.setSelfImprove(true)
    }

    fun daily(store: AgentStore, force: Boolean = false): Int {
        bootstrap(store)
        if (!store.selfImproveEnabled()) return 0
        val now = System.currentTimeMillis()
        val last = store.getValue("last_language_sync").toLongOrNull() ?: 0L
        if (!force && now - last < DAY) return 0
        var index = store.getValue("tr_rule_index").toIntOrNull() ?: 9
        var added = 0
        repeat(if (force) 3 else 1) {
            if (index < rules.size) { store.addLanguageRule(rules[index]); index++; added++ }
        }
        store.setValue("tr_rule_index", index.toString())
        store.setValue("last_language_sync", now.toString())
        return added
    }

    fun observeUser(store: AgentStore, text: String) {
        if (!store.selfImproveEnabled() || text.length !in 6..420) return
        Regex("(?iu)bundan sonra\\s+(.+)").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            if (it.length >= 8) store.addLanguageRule("Kullanıcı tercihi: ${it.take(260)}")
        }
        if (Regex("(?iu)\\b(uydurma|tahmin etme|kaynak göster|kısa cevap|uzatma)\\b").containsMatchIn(text)) {
            store.addLanguageRule("Kullanıcının davranış düzeltmesi: ${text.take(240)}")
        }
    }
}
