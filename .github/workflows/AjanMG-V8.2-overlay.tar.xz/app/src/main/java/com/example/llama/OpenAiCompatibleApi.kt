package com.example.llama

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class OpenAiProviderConfig(
    val id: String,
    val label: String,
    val baseUrl: String,
    val model: String,
    val apiKey: String
)

class OpenAiCompatibleApi(private val config: OpenAiProviderConfig) {
    data class FunctionCall(val name: String, val args: JSONObject, val id: String)
    data class AgentStep(val message: JSONObject, val text: String, val call: FunctionCall?)

    fun agentStep(messages: JSONArray, tools: JSONArray): AgentStep {
        val openAiTools = JSONArray()
        for (i in 0 until tools.length()) {
            val fn = tools.optJSONObject(i) ?: continue
            openAiTools.put(JSONObject().put("type", "function").put("function", fn))
        }
        val body = JSONObject()
            .put("model", config.model)
            .put("messages", messages)
            .put("tools", openAiTools)
            .put("tool_choice", "auto")
            .put("parallel_tool_calls", false)
            .put("temperature", if (config.id == "nvidia") 1.0 else 0.3)
        if (config.id == "nvidia") {
            body.put("chat_template_kwargs", JSONObject().put("enable_thinking", true).put("force_nonempty_content", true))
        }
        val root = postJson("${base()}/chat/completions", body)
        val message = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            ?: error(apiError(root, "${config.label} yanıt üretmedi."))
        val text = when (val c = message.opt("content")) {
            is String -> c.trim()
            is JSONArray -> buildString {
                for (i in 0 until c.length()) {
                    val b = c.optJSONObject(i) ?: continue
                    val t = b.optString("text")
                    if (t.isNotBlank()) { if (isNotEmpty()) append('\n'); append(t) }
                }
            }.trim()
            else -> ""
        }
        var call: FunctionCall? = null
        val calls = message.optJSONArray("tool_calls")
        if (calls != null && calls.length() > 0) {
            val tc = calls.optJSONObject(0)
            val fn = tc?.optJSONObject("function")
            if (tc != null && fn != null) {
                val rawArgs = fn.optString("arguments", "{}")
                call = FunctionCall(
                    fn.optString("name"),
                    runCatching { JSONObject(rawArgs.ifBlank { "{}" }) }.getOrElse { JSONObject() },
                    tc.optString("id").ifBlank { "call_${System.currentTimeMillis()}" }
                )
            }
        }
        return AgentStep(message, text, call)
    }

    fun testConnection(): String {
        val root = getJson("${base()}/models")
        val data = root.optJSONArray("data") ?: return config.model
        for (i in 0 until data.length()) {
            val id = data.optJSONObject(i)?.optString("id").orEmpty()
            if (id == config.model) return id
        }
        return config.model
    }

    private fun base(): String = config.baseUrl.trim().trimEnd('/').ifBlank { error("${config.label} API adresi boş.") }

    private fun postJson(url: String, body: JSONObject, timeout: Int = 120000): JSONObject {
        if (config.apiKey.isBlank()) error("${config.label} API anahtarı ayarlanmamış.")
        if (config.model.isBlank()) error("${config.label} model adı ayarlanmamış.")
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 15000; readTimeout = timeout
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer ${config.apiKey}")
            setRequestProperty("Accept-Encoding", "identity")
        }
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (raw.isBlank()) error("${config.label} boş yanıt verdi (HTTP $code).")
        val root = runCatching { JSONObject(raw) }.getOrElse { error("${config.label} geçersiz yanıt verdi (HTTP $code): ${raw.take(500)}") }
        if (code !in 200..299) error(apiError(root, "${config.label} API hatası (HTTP $code)."))
        return root
    }

    private fun getJson(url: String): JSONObject {
        if (config.apiKey.isBlank()) error("${config.label} API anahtarı ayarlanmamış.")
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 12000; readTimeout = 30000
            setRequestProperty("Authorization", "Bearer ${config.apiKey}")
            setRequestProperty("Accept-Encoding", "identity")
        }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (raw.isBlank()) error("${config.label} durum yanıtı boş (HTTP $code).")
        val root = runCatching { JSONObject(raw) }.getOrElse { error("${config.label} geçersiz durum yanıtı verdi.") }
        if (code !in 200..299) error(apiError(root, "${config.label} durum hatası (HTTP $code)."))
        return root
    }

    private fun apiError(root: JSONObject, fallback: String): String {
        val error = root.opt("error")
        return when (error) {
            is JSONObject -> error.optString("message").ifBlank { fallback }
            is String -> error.ifBlank { fallback }
            else -> root.optString("message").ifBlank { fallback }
        }
    }
}
