package com.example.llama

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

class RemoteTools(private val context: Context, private val secrets: SecureSecrets) {
    fun openUrl(url: String): String {
        val target = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://www.google.com/search?q=${URLEncoder.encode(url, "UTF-8")}" 
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Tarayıcı açıldı: $target"
    }

    fun pcCommand(command: String, payload: JSONObject): String {
        val base = secrets.get("pc_bridge_url").trimEnd('/')
        val token = secrets.get("pc_bridge_token")
        if (base.isBlank()) return "PC Bridge ayarlanmamış. Ayarlardan bilgisayar adresini ekle."
        if (token.isBlank()) return "PC Bridge token ayarlanmamış. Güvenlik için token zorunlu."
        val body = JSONObject().put("command", command).put("payload", payload)
        return post("$base/v1/command", body, token, "X-Ajan-Token")
    }

    fun githubGetFile(repo: String, path: String, ref: String = "main"): String {
        val token = secrets.get("github_token")
        if (token.isBlank()) return "GitHub token ayarlanmamış."
        val encoded = encodePath(path)
        val (code, raw) = githubRequest("https://api.github.com/repos/$repo/contents/$encoded?ref=${URLEncoder.encode(ref, "UTF-8")}", "GET", null, token)
        if (code !in 200..299) return "GitHub hatası HTTP $code: ${message(raw)}"
        val o = JSONObject(raw)
        val content = runCatching { String(Base64.decode(o.optString("content").replace("\n", ""), Base64.DEFAULT), Charsets.UTF_8) }.getOrDefault("")
        return JSONObject().put("sha", o.optString("sha")).put("path", o.optString("path", path)).put("content", content.take(180000)).toString()
    }

    fun githubPut(repo: String, path: String, content: String, message: String, sha: String? = null): String {
        val token = secrets.get("github_token")
        if (token.isBlank()) return "GitHub token ayarlanmamış."
        val encoded = encodePath(path)
        var currentSha = sha
        if (currentSha.isNullOrBlank()) {
            val (getCode, getRaw) = githubRequest("https://api.github.com/repos/$repo/contents/$encoded", "GET", null, token)
            if (getCode in 200..299) currentSha = runCatching { JSONObject(getRaw).optString("sha") }.getOrNull()?.ifBlank { null }
            else if (getCode != 404) return "GitHub dosya kontrol hatası HTTP $getCode: ${message(getRaw)}"
        }
        val body = JSONObject().put("message", message.ifBlank { "Ajan M&G update" })
            .put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
        if (!currentSha.isNullOrBlank()) body.put("sha", currentSha)
        val (code, raw) = githubRequest("https://api.github.com/repos/$repo/contents/$encoded", "PUT", body, token)
        return if (code in 200..299) {
            val o = runCatching { JSONObject(raw) }.getOrNull()
            "GitHub işlemi başarılı (HTTP $code). Commit: ${o?.optJSONObject("commit")?.optString("sha").orEmpty().take(12)}"
        } else "GitHub hatası HTTP $code: ${message(raw)}"
    }

    fun githubRuns(repo: String): String {
        val token = secrets.get("github_token")
        if (token.isBlank()) return "GitHub token ayarlanmamış."
        val (code, raw) = githubRequest("https://api.github.com/repos/$repo/actions/runs?per_page=5", "GET", null, token)
        if (code !in 200..299) return "GitHub hatası HTTP $code: ${message(raw)}"
        val arr = JSONObject(raw).optJSONArray("workflow_runs") ?: return "Workflow çalışması bulunamadı."
        val out = org.json.JSONArray()
        for (i in 0 until minOf(arr.length(), 5)) {
            val r = arr.optJSONObject(i) ?: continue
            out.put(JSONObject().put("id", r.optLong("id")).put("name", r.optString("name")).put("status", r.optString("status")).put("conclusion", r.optString("conclusion")).put("sha", r.optString("head_sha").take(12)).put("url", r.optString("html_url")))
        }
        return out.toString()
    }

    fun githubDispatch(repo: String, workflow: String, ref: String = "main"): String {
        val token = secrets.get("github_token")
        if (token.isBlank()) return "GitHub token ayarlanmamış."
        val body = JSONObject().put("ref", ref)
        val wf = URLEncoder.encode(workflow, "UTF-8")
        val (code, raw) = githubRequest("https://api.github.com/repos/$repo/actions/workflows/$wf/dispatches", "POST", body, token)
        return if (code in 200..299) "GitHub Actions başlatıldı (HTTP $code)." else "GitHub hatası HTTP $code: ${message(raw)}"
    }

    private fun githubRequest(url: String, method: String, body: JSONObject?, token: String): Pair<Int, String> {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method; doOutput = body != null; connectTimeout = 10000; readTimeout = 35000
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            if (body != null) setRequestProperty("Content-Type", "application/json")
        }
        if (body != null) c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect(); return code to raw
    }

    private fun post(url: String, body: JSONObject, token: String, tokenHeader: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 8000; readTimeout = 45000
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty(tokenHeader, token)
        }
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        return if (code in 200..299) raw.ifBlank { "PC komutu başarılı." }.take(12000) else "PC Bridge hatası HTTP $code: ${raw.take(1500)}"
    }

    private fun encodePath(path: String) = path.split('/').joinToString("/") { Uri.encode(it) }
    private fun message(raw: String) = runCatching { JSONObject(raw).optString("message") }.getOrDefault(raw).ifBlank { "Bilinmeyen hata" }.take(700)
}
