package com.example.llama

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

object MediaStudio {
    fun saveImage(context: Context, bytes: ByteArray, name: String = fileName("AjanMG-4K", "jpg")): Uri =
        save(context, bytes, name, "image/jpeg", MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "Pictures/Ajan M&G")

    fun saveVideo(context: Context, bytes: ByteArray, name: String = fileName("AjanMG-Video", "mp4")): Uri =
        save(context, bytes, name, "video/mp4", MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/Ajan M&G")

    fun saveMusic(context: Context, bytes: ByteArray, name: String = fileName("AjanMG-Muzik", "mp3")): Uri =
        save(context, bytes, name, "audio/mpeg", MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "Music/Ajan M&G")

    fun saveDocument(context: Context, bytes: ByteArray, name: String, mime: String): Uri =
        save(context, bytes, name, mime, MediaStore.Files.getContentUri("external"), "Documents/Ajan M&G")

    fun createCameraUri(context: Context): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName("AjanMG-Kamera", "jpg"))
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Ajan M&G/Original")
        }
        return context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Kamera dosyası oluşturulamadı.")
    }

    fun readBytes(context: Context, uri: Uri, maxBytes: Int = 18_000_000): ByteArray {
        return context.contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var total = 0
            while (true) {
                val n = input.read(buf); if (n <= 0) break
                total += n; if (total > maxBytes) error("Dosya çok büyük. En fazla ${maxBytes / 1_000_000} MB kullan.")
                out.write(buf, 0, n)
            }
            out.toByteArray()
        } ?: error("Dosya okunamadı.")
    }

    private fun save(context: Context, bytes: ByteArray, name: String, mime: String, collection: Uri, folder: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(name))
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
        }
        val uri = context.contentResolver.insert(collection, values) ?: error("Dosya kaydı oluşturulamadı.")
        try {
            context.contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) } ?: error("Dosyaya yazılamadı.")
            return uri
        } catch (e: Exception) {
            context.contentResolver.delete(uri, null, null)
            throw e
        }
    }

    fun fileName(prefix: String, ext: String): String = "$prefix-${java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US).format(java.util.Date())}.$ext"
    private fun safeName(v: String) = v.replace(Regex("[\\/:*?\"<>|]"), "_").take(90)
}
