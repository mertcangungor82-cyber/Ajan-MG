package com.example.llama

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class GeminiApi(private val secrets: SecureSecrets) {
    private fun base(): String = secrets.get("gemini_base_url").ifBlank { "https://generativelanguage.googleapis.com/v1beta" }.trimEnd('/')
    private fun key(): String = secrets.get("gemini_api_key").ifBlank { error("Gemini API anahtarı ayarlanmamış.") }
    private fun chatModel(): String = secrets.get("gemini_chat_model").ifBlank { "gemini-3.8-flash" }
    private fun imageModel(): String = secrets.get("gemini_image_model").ifBlank { "gemini-3.1-flash-image" }
    private fun videoModel(): String = secrets.get("gemini_video_model").ifBlank { "veo-3.1-generate-preview" }
    private fun musicModel(fullSong: Boolean): String = if (fullSong) secrets.get("gemini_music_model").ifBlank { "lyria-3.5" } else secrets.get("gemini_music_clip_model").ifBlank { "lyria-3-clip-preview" }

    data class FunctionCall(val name: String, val args: JSONObject, val id: String? = null)
    data class AgentStep(val modelContent: JSONObject, val text: String, val call: FunctionCall?)
    data class BinaryResult(val bytes: ByteArray, val mime: String, val text: String = "")

    fun agentStep(contents: JSONArray, system: String, tools: JSONArray): AgentStep {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("tools", JSONArray()
                .put(JSONObject().put("googleSearch", JSONObject()))
                .put(JSONObject().put("functionDeclarations", tools)))
            .put("toolConfig", JSONObject().put("includeServerSideToolInvocations", true))
            .put("generationConfig", JSONObject().put("temperature", 0.35).put("maxOutputTokens", 8192))
        val root = postJson("${base()}/models/${chatModel()}:generateContent", body)
        val content = root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
            ?: error(apiError(root, "Gemini yanıt üretmedi."))
        val parts = content.optJSONArray("parts") ?: JSONArray()
        val text = StringBuilder()
        var call: FunctionCall? = null
        for (i in 0 until parts.length()) {
            val p = parts.optJSONObject(i) ?: continue
            p.optString("text").takeIf { it.isNotBlank() }?.let { if (text.isNotEmpty()) text.append('\n'); text.append(it) }
            val fc = p.optJSONObject("functionCall") ?: p.optJSONObject("function_call")
            if (fc != null && call == null) {
                call = FunctionCall(
                    fc.optString("name"),
                    fc.optJSONObject("args") ?: JSONObject(),
                    fc.optString("id").ifBlank { null }
                )
            }
        }
        return AgentStep(content, text.toString().trim(), call)
    }


    fun testConnection(): String {
        val root = getJson("${base()}/models/${chatModel()}", 20000)
        return root.optString("displayName").ifBlank { root.optString("name", chatModel()) }
    }

    fun generateImage(prompt: String, input: ByteArray? = null, mime: String = "image/jpeg", aspect: String = "1:1", size: String = "4K"): BinaryResult {
        val inValue: Any = if (input == null) prompt else JSONArray()
            .put(JSONObject().put("type", "text").put("text", prompt))
            .put(JSONObject().put("type", "image").put("mime_type", mime).put("data", Base64.encodeToString(input, Base64.NO_WRAP)))
        val body = JSONObject()
            .put("model", imageModel())
            .put("input", inValue)
            .put("response_format", JSONObject().put("type", "image").put("mime_type", "image/jpeg").apply { if (aspect.isNotBlank()) put("aspect_ratio", aspect); put("image_size", size) })
        val root = postJson("${base()}/interactions", body)
        return parseInteractionBinary(root, "image", "image/jpeg")
    }

    fun generateMusic(prompt: String, fullSong: Boolean): BinaryResult {
        val body = JSONObject()
            .put("model", musicModel(fullSong))
            .put("input", prompt)
        val root = postJson("${base()}/interactions", body, readTimeout = 180000)
        return parseInteractionBinary(root, "audio", "audio/mpeg")
    }

    fun generateVideo(prompt: String, aspect: String = "9:16", resolution: String = "1080p"): BinaryResult {
        val body = JSONObject()
            .put("instances", JSONArray().put(JSONObject().put("prompt", prompt)))
            .put("parameters", JSONObject().put("aspectRatio", aspect).put("durationSeconds", "8").put("resolution", resolution).put("personGeneration", "allow_all"))
        val op = postJson("${base()}/models/${videoModel()}:predictLongRunning", body, readTimeout = 60000)
        val name = op.optString("name").ifBlank { error(apiError(op, "Video üretimi başlatılamadı.")) }
        var status = op
        for (attempt in 0 until 90) {
            if (status.optBoolean("done", false)) {
                val uri = status.optJSONObject("response")?.optJSONObject("generateVideoResponse")
                    ?.optJSONArray("generatedSamples")?.optJSONObject(0)?.optJSONObject("video")?.optString("uri").orEmpty()
                if (uri.isBlank()) error(apiError(status, "Video tamamlandı ancak dosya adresi alınamadı."))
                return BinaryResult(download(uri, "video/mp4", 180000), "video/mp4")
            }
            Thread.sleep(10000)
            status = getJson("${base()}/$name", 45000)
        }
        error("Video üretimi zaman aşımına uğradı.")
    }

    private fun parseInteractionBinary(root: JSONObject, type: String, fallbackMime: String): BinaryResult {
        val steps = root.optJSONArray("steps") ?: JSONArray()
        var text = ""
        for (i in 0 until steps.length()) {
            val step = steps.optJSONObject(i) ?: continue
            if (step.optString("type") != "model_output") continue
            val content = step.optJSONArray("content") ?: JSONArray()
            for (j in 0 until content.length()) {
                val block = content.optJSONObject(j) ?: continue
                when (block.optString("type")) {
                    "text" -> if (block.optString("text").isNotBlank()) text += block.optString("text") + "\n"
                    type -> {
                        val data = block.optString("data")
                        if (data.isNotBlank()) return BinaryResult(Base64.decode(data, Base64.DEFAULT), block.optString("mime_type", fallbackMime), text.trim())
                    }
                }
            }
        }
        error(apiError(root, "Gemini $type çıktısı döndürmedi."))
    }

    private fun postJson(url: String, body: JSONObject, readTimeout: Int = 90000): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 12000; this.readTimeout = readTimeout
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key())
            setRequestProperty("Accept-Encoding", "identity")
        }
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (raw.isBlank()) error("Gemini API boş yanıt verdi (HTTP $code).")
        val root = JSONObject(raw)
        if (code !in 200..299) error(apiError(root, "Gemini API hatası (HTTP $code)."))
        return root
    }

    private fun getJson(url: String, readTimeout: Int): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 12000; this.readTimeout = readTimeout
            setRequestProperty("x-goog-api-key", key()); setRequestProperty("Accept-Encoding", "identity")
        }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (raw.isBlank()) error("Gemini durum yanıtı boş (HTTP $code).")
        val root = JSONObject(raw)
        if (code !in 200..299) error(apiError(root, "Gemini durum hatası (HTTP $code)."))
        return root
    }

    private fun download(url: String, mime: String, timeout: Int): ByteArray {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 12000; readTimeout = timeout; instanceFollowRedirects = true
            setRequestProperty("x-goog-api-key", key()); setRequestProperty("Accept", mime); setRequestProperty("Accept-Encoding", "identity")
        }
        if (c.responseCode !in 200..299) error("Üretilen dosya indirilemedi (HTTP ${c.responseCode}).")
        val out = ByteArrayOutputStream(); c.inputStream.use { it.copyTo(out) }; c.disconnect(); return out.toByteArray()
    }

    private fun apiError(root: JSONObject, fallback: String): String = root.optJSONObject("error")?.optString("message").orEmpty().ifBlank { fallback }
}
