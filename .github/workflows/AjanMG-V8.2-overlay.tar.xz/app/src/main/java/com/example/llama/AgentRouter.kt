package com.example.llama

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class AgentAction {
    data class Chat(val text: String) : AgentAction()
    data class Web(val query: String) : AgentAction()
    data class Immediate(val text: String) : AgentAction()
    data object Backup : AgentAction()
    data object Restore : AgentAction()
    data object ImportFile : AgentAction()
    data object LearnTurkish : AgentAction()
    data class Project(val name: String) : AgentAction()
}

class AgentRouter(private val store: AgentStore) {
    private val tr = Locale("tr", "TR")

    init {
        LanguageLearner.bootstrap(store)
        val oldMemory = store.getValue("memory")
        if (oldMemory.isNotBlank()) learnIdentityFacts(oldMemory)
    }

    fun route(text: String): AgentAction {
        val lower = text.lowercase(tr).trim()
        if (store.selfImproveEnabled()) LanguageLearner.observeUser(store, text)

        localUtility(lower)?.let { return AgentAction.Immediate(it) }
        if (lower in setOf("merhaba", "selam", "günaydın", "iyi akşamlar")) {
            val n = store.getValue("user_name")
            return AgentAction.Immediate(if (n.isBlank()) "Merhaba! Nasıl yardımcı olayım?" else "Merhaba $n! Nasıl yardımcı olayım?")
        }
        if (lower in setOf("teşekkürler", "teşekkür ederim", "sağ ol", "sağol")) return AgentAction.Immediate("Rica ederim.")

        if (lower == "/backup" || lower == "/drive") return AgentAction.Backup
        if (lower == "/restore") return AgentAction.Restore
        if (lower == "/file") return AgentAction.ImportFile
        if (lower == "/turkce-ogren" || lower == "/türkçe-öğren") return AgentAction.LearnTurkish
        if (lower.startsWith("/project ")) return AgentAction.Project(text.substringAfter(" ").trim())
        if (lower == "/gelişim" || lower == "/gelisim" || lower == "/self") return AgentAction.Immediate(store.developmentSummary())
        if (lower in setOf("/gelişim aç", "/gelisim ac", "/self on")) { store.setSelfImprove(true); return AgentAction.Immediate("Kendini geliştirme modu açık.") }
        if (lower in setOf("/gelişim kapat", "/gelisim kapat", "/self off")) { store.setSelfImprove(false); return AgentAction.Immediate("Kendini geliştirme modu kapalı.") }

        if (lower == "/memory") {
            val m = store.getValue("memory")
            return AgentAction.Immediate(if (m.isBlank()) "Kalıcı hafıza boş." else "Kalıcı hafıza:\n$m")
        }

        if (lower.startsWith("/memory ")) {
            val body = text.substringAfter(" ").trim()
            store.appendMemory(body)
            val learned = learnIdentityFacts(body)
            val extra = when {
                learned.contains("user") && learned.contains("assistant") ->
                    " Adını ${store.getValue("user_name")}, benim adımı ${assistantName()} olarak ayrı ayrı kaydettim."
                learned.contains("user") -> " Adını ${store.getValue("user_name")} olarak kaydettim."
                learned.contains("assistant") -> " Benim adımı ${assistantName()} olarak kaydettim."
                else -> ""
            }
            return AgentAction.Immediate("Bunu kalıcı hafızama kaydettim.$extra")
        }

        if (lower.startsWith("/duzelt ") || lower.startsWith("/düzelt ")) {
            val p = text.substringAfter(" ").split("=>", limit = 2)
            if (p.size == 2) {
                store.addCorrection(p[0], p[1])
                return AgentAction.Immediate("Türkçe düzeltmeni kalıcı olarak öğrendim.")
            }
            return AgentAction.Immediate("Biçim: /düzelt yanlış ifade => doğru ifade")
        }

        naturalCorrection(text)?.let { (wrong, right) ->
            store.addCorrection(wrong, right)
            return AgentAction.Immediate("Tamam. Bundan sonra bu ifadeyi düzeltilmiş biçimiyle kullanacağım.")
        }

        identityAction(text, lower)?.let { return it }

        if (lower == "/status") {
            return AgentAction.Immediate(
                "Ajan M&G hazır. AUTO web yönlendirme, kalıcı hafıza, sohbet geçmişi, Türkçe davranış belleği, dosya bağlama, yedekleme, canlı ses ve kendini geliştirme modu ${if (store.selfImproveEnabled()) "açık" else "kapalı"}."
            )
        }

        if (lower == "/help" || lower == "/tools") {
            return AgentAction.Immediate(
                "AUTO ajan açık. /web, /memory, /düzelt, /gelişim, /turkce-ogren, /file, /backup, /restore, /project komutları kullanılabilir. Güncel ve sayısal sorular otomatik web doğrulamasına gider; CANLI mod cevabı sesli okur; 📎 DOSYA tek mesaja dosya bağlar."
            )
        }

        webQuery(text)?.let { return AgentAction.Web(it) }
        return AgentAction.Chat(text)
    }

    fun promptForChat(userText: String, attachmentName: String? = null, attachmentText: String? = null): String {
        val memory = store.getValue("memory")
        val lang = store.languageContext()
        val history = store.conversationContext()
        val userName = store.getValue("user_name")
        val now = SimpleDateFormat("d MMMM yyyy EEEE HH:mm", tr).format(Date())
        val agentName = assistantName()

        return buildString {
            append("Sen Ajan M&G adlı kişisel Android yapay zeka ajanısın. Kullanıcının sana verdiği hitap adı: ").append(agentName).append(".\n")
            append("Her zaman doğal, düzgün, akıcı Türkçe kullan. Kullanıcının cümlesini papağan gibi tekrar etme.\n")
            append("Soruyu doğrudan cevapla. Gereksiz başlık, özür, giriş ve İngilizce kalıp kullanma.\n")
            append("Bilmediğin veya güncelliği gereken şeyi uydurma; güncel bilgi web aracına yönlendirilmelidir.\n")
            append("Kullanıcı kendi adını sorarsa kullanıcı adını, senin adını sorarsa hitap adını karıştırmadan cevapla.\n")
            append("Şu an: ").append(now).append(".\n")
            if (userName.isNotBlank()) append("Kullanıcının adı: ").append(userName).append(".\n")
            if (history.isNotBlank()) append("\n[SON SOHBET]\n").append(history.takeLast(1400))
            if (memory.isNotBlank()) append("\n[KALICI HAFIZA]\n").append(memory.takeLast(1800))
            if (lang.isNotBlank()) append("\n[TÜRKÇE KURALLARI]\n").append(lang.takeLast(1200))
            if (!attachmentText.isNullOrBlank()) {
                append("\n[EKLİ DOSYA: ").append(attachmentName ?: "dosya").append("]\n")
                append(attachmentText.take(7000))
                append("\nDosyayı yalnızca soruyla ilgili olduğu ölçüde kullan. Dosyada yoksa varmış gibi davranma.\n")
            }
            append("\n[KULLANICI]\n").append(userText)
            append("\n[").append(agentName).append("]\n")
        }
    }

    fun promptForWeb(query: String, research: String): String =
        """
        Sen ${assistantName()} adlı Ajan M&G'sin. Aşağıdaki güncel web sonuçlarına dayanarak kullanıcının sorusunu doğal Türkçe ile doğrudan cevapla.
        Kurallar: En yeni ve birbiriyle uyumlu sonuçları tercih et. Kaynakta olmayan bilgiyi uydurma. Skor, sayı, tarih ve isimleri değiştirme.
        Çelişki varsa bunu tek cümlede belirt. Cevap mümkünse 2-5 kısa cümle olsun. Kullanıcının sorusunu tekrar etme.
        En sonda yalnızca gerçekten kullandığın en fazla 3 kaynak için kısa "Kaynaklar:" satırı ver.

        SORU: $query

        WEB SONUÇLARI:
        ${research.take(9000)}

        TÜRKÇE ÜSLUP:
        ${store.languageContext().take(1800)}
        """.trimIndent()

    private fun assistantName(): String = store.getValue("assistant_name").ifBlank { "Ajan M&G" }

    private fun learnIdentityFacts(text: String): Set<String> {
        val learned = linkedSetOf<String>()
        val user = Regex("(?iu)\\bbenim\\s+adım(?:\\s+ise)?\\s+([\\p{L}][\\p{L}'’-]{1,30})").find(text)
            ?.groupValues?.getOrNull(1)?.trim().orEmpty()
        if (user.isNotBlank() && user.lowercase(tr) !in setOf("ne", "nedir", "neydi")) {
            store.setValue("user_name", niceName(user))
            learned += "user"
        }

        val assistant = Regex("(?iu)\\bsenin\\s+adın(?:\\s+ise)?\\s+([\\p{L}][\\p{L}'’-]{1,30})").find(text)
            ?.groupValues?.getOrNull(1)?.trim().orEmpty()
        if (assistant.isNotBlank() && assistant.lowercase(tr) !in setOf("ne", "nedir", "neydi")) {
            store.setValue("assistant_name", niceName(assistant))
            learned += "assistant"
        }
        return learned
    }

    private fun identityAction(text: String, lower: String): AgentAction? {
        val asksUserName = lower.matches(Regex(".*\\b(benim\\s+adım|adım)\\s+(ne|nedir|neydi)\\??$")) ||
            lower == "adımı biliyor musun" || lower == "beni nasıl kaydettin"
        if (asksUserName) {
            val name = store.getValue("user_name")
            return AgentAction.Immediate(if (name.isBlank()) "Adını henüz kalıcı hafızama kaydetmedim." else "Adın $name.")
        }

        val asksAssistantName = lower.matches(Regex(".*\\b(senin\\s+adın|adın)\\s+(ne|nedir|neydi)\\??$")) &&
            !lower.contains("benim adım")
        if (asksAssistantName) {
            return AgentAction.Immediate("Benim adım ${assistantName()}.")
        }

        val learned = learnIdentityFacts(text)
        if (learned.isNotEmpty() && !lower.contains("?") && !lower.contains(" ne ")) {
            val body = when {
                learned.contains("user") && learned.contains("assistant") ->
                    "Tamam. Adını ${store.getValue("user_name")}, benim adımı ${assistantName()} olarak ayrı ayrı hatırlayacağım."
                learned.contains("user") -> "Tamam ${store.getValue("user_name")}. Adını kalıcı hafızama kaydettim."
                else -> "Tamam. Benim adım ${assistantName()}."
            }
            store.appendMemory(text)
            return AgentAction.Immediate(body)
        }
        return null
    }

    private fun niceName(raw: String): String {
        val clean = raw.trim().trim(',', '.', ';', ':', '!', '?').take(32)
        return clean.replaceFirstChar { if (it.isLowerCase()) it.titlecase(tr) else it.toString() }
    }

    private fun localUtility(lower: String): String? {
        val now = Date()
        if (lower == "saat kaç" || lower == "saat kaç?" || lower.contains("şu an saat kaç") || lower.contains("şimdi saat kaç")) {
            return "Saat ${SimpleDateFormat("HH:mm", tr).format(now)}."
        }
        if (lower == "bugün tarih ne" || lower == "bugünün tarihi ne" || lower.contains("bugün ayın kaçı")) {
            return "Bugün ${SimpleDateFormat("d MMMM yyyy EEEE", tr).format(now)}."
        }
        return null
    }

    private fun webQuery(text: String): String? {
        val lower = text.lowercase(tr)
        if (lower.startsWith("/web ")) return normalizeWebQuery(text.substringAfter(" ").trim())

        val explicit = listOf(
            Regex("(?i)^internetten\\s+araştır\\s+(.+)$"), Regex("(?i)^internette\\s+araştır\\s+(.+)$"),
            Regex("(?i)^internetten\\s+(.+?)\\s+araştır$"), Regex("(?i)^internette\\s+(.+?)\\s+araştır$"),
            Regex("(?i)^webde\\s+(.+?)\\s+(ara|araştır)$"), Regex("(?i)^araştır\\s+(.+)$")
        )
        explicit.forEach { r -> r.find(text)?.let { return normalizeWebQuery(it.groupValues[1].trim()) } }

        val liveTerms = listOf(
            "son maç", "maç skoru", "maç sonucu", "puan durumu", "fikstür", "canlı skor", "skoru", "kim kazandı",
            "hava nasıl", "hava durumu", "yağmur", "sıcaklık", "kaç derece",
            "son haber", "güncel haber", "bugünkü haber", "transfer", "deprem",
            "dolar", "euro", "sterlin", "altın", "bitcoin", "borsa", "fiyatı ne", "kaç tl",
            "güncel", "bugün ne oldu", "seçim sonucu", "son durum", "en son"
        )
        if (liveTerms.any { lower.contains(it) }) return normalizeWebQuery(text)

        if ((lower.contains("bugün") || lower.contains("yarın") || lower.contains("şu an")) &&
            listOf("maç", "hava", "haber", "fiyat", "kur", "sonuç", "etkinlik", "skor", "sıra", "puan").any { lower.contains(it) }
        ) return normalizeWebQuery(text)

        val noWeb = listOf("nasılsın", "sen kimsin", "senin adın", "benim adım", "şaka", "hikaye", "şiir", "çevir", "özetle", "yazı yaz")
        if (noWeb.any { lower.contains(it) }) return null
        val factual = listOf("nüfus", "kaç milyon", "kaç kişi", "kaçıncı", "ligde", "sıralama", "puanı", "kimdir", "nedir", "nerede", "ne zaman", "hangi", "ne kadar")
        if (factual.any { lower.contains(it) }) return normalizeWebQuery(text)
        if ((lower.contains(" kaç ") || lower.endsWith("?")) && !lower.contains("benim") && !lower.contains("senin")) return normalizeWebQuery(text)

        return null
    }

    private fun normalizeWebQuery(text: String): String {
        var q = text.trim()
        q = q.replace(Regex("(?iu)\\bgs\\b"), "Galatasaray")
        q = q.replace(Regex("(?iu)\\bfb\\b"), "Fenerbahçe")
        q = q.replace(Regex("(?iu)\\bbjk\\b"), "Beşiktaş")
        q = q.replace(Regex("(?iu)\\bts\\b"), "Trabzonspor")
        return q
    }

    private fun naturalCorrection(text: String): Pair<String, String>? {
        val m = Regex("(?i)böyle\\s+deme[: ]+(.+?)[,; ]+şöyle\\s+de[: ]+(.+)$").find(text) ?: return null
        return m.groupValues[1].trim() to m.groupValues[2].trim()
    }
}
